"""
AQI Prediction Pipeline
========================
Standalone, Colab-free version of the original notebook
(public/AQI_Monitoring_python_file.ipynb).

What changed vs. the original notebook:
  - No google.colab.drive dependency — works on any machine.
  - All paths are CLI arguments / a config block instead of hardcoded
    "/content/drive/My Drive/..." strings.
  - The hardcoded MongoDB Atlas connection string (with a plaintext
    username/password) has been REMOVED. That credential was committed
    in the original notebook and should be rotated in MongoDB Atlas —
    treat it as compromised. Mongo export now reads the URI from the
    MONGODB_URI environment variable instead.
  - Wrapped optional/heavy steps (Prophet forecasting, Mongo export) in
    try/except so the core pipeline (merge -> impute -> train -> cluster)
    still completes even if those pieces aren't needed or configured.
  - Added basic logging and input validation so failures are readable
    instead of silent KeyErrors.

Usage:
    python aqi_pipeline.py --data-dir ./data --out-dir ./outputs

Expected input files in --data-dir:
    CPCB.csv          (Latitude, Longitude, From Date, To Date, PM2.5, PM10, ...)
    INSAT_3DR.csv      (latitude, longitude, aod, ...)
    MERRA_NASA.csv     (lat, lon, u, v, rh, t, ...)
"""

import argparse
import logging
import os
import sys

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
log = logging.getLogger("aqi_pipeline")


def load_inputs(data_dir):
    paths = {
        "cpcb": os.path.join(data_dir, "CPCB.csv"),
        "insat": os.path.join(data_dir, "INSAT_3DR.csv"),
        "merra": os.path.join(data_dir, "MERRA_NASA.csv"),
    }
    missing = [name for name, p in paths.items() if not os.path.exists(p)]
    if missing:
        raise FileNotFoundError(
            f"Missing required input file(s): {missing}. "
            f"Expected them inside {data_dir}"
        )

    cpcb = pd.read_csv(paths["cpcb"])
    insat = pd.read_csv(paths["insat"], on_bad_lines="skip")
    merra = pd.read_csv(paths["merra"])

    cpcb.columns = cpcb.columns.str.strip()
    insat.columns = insat.columns.str.strip().str.lower()
    merra.columns = merra.columns.str.strip().str.lower()

    log.info("Loaded CPCB %s, INSAT %s, MERRA %s", cpcb.shape, insat.shape, merra.shape)
    return cpcb, insat, merra


def merge_datasets(cpcb, insat, merra):
    merra = merra.copy()
    merra["ws"] = np.sqrt(merra["u"] ** 2 + merra["v"] ** 2)

    cpcb_coords = cpcb[["Latitude", "Longitude"]].values
    insat_coords = insat[["latitude", "longitude"]].values
    merra_coords = merra[["lat", "lon"]].values

    tree_insat = cKDTree(insat_coords)
    tree_merra = cKDTree(merra_coords)

    _, idx_insat = tree_insat.query(cpcb_coords)
    _, idx_merra = tree_merra.query(cpcb_coords)

    merged = cpcb.copy()
    merged["AOD"] = insat.iloc[idx_insat]["aod"].values
    merged["RH_MERRA"] = merra.iloc[idx_merra]["rh"].values
    merged["WS_MERRA"] = merra.iloc[idx_merra]["ws"].values
    merged["T_MERRA"] = merra.iloc[idx_merra]["t"].values
    merged["T_MERRA_C"] = merged["T_MERRA"] - 273.15

    log.info("Merged dataset shape: %s", merged.shape)
    return merged


def clean_and_engineer(merged):
    impute_cols = [
        "PM2.5", "PM10", "NO", "NO2", "NOx", "NH3", "SO2", "CO", "Ozone",
        "Benzene", "Toluene", "Eth-Benzene", "MP-Xylene", "O-Xylene",
        "RH", "WS", "WD", "SR", "BP", "VWS",
        "AOD", "RH_MERRA", "WS_MERRA", "T_MERRA",
    ]
    for col in impute_cols:
        if col in merged.columns:
            merged[col] = merged[col].fillna(merged[col].median())

    if "From Date" in merged.columns:
        merged["From Date"] = pd.to_datetime(
            merged["From Date"], format="mixed", dayfirst=True, errors="coerce"
        )
        merged = merged.dropna(subset=["From Date"])
        merged["Year"] = merged["From Date"].dt.year
        merged["Month"] = merged["From Date"].dt.month
        merged["Day"] = merged["From Date"].dt.day
        merged["Weekday"] = merged["From Date"].dt.weekday

    log.info("Remaining nulls after cleaning:\n%s", merged.isnull().sum()[merged.isnull().sum() > 0])
    return merged


def train_models(merged, out_dir):
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import mean_squared_error
    import joblib

    features = ["AOD", "RH_MERRA", "WS_MERRA", "T_MERRA"]
    X = merged[features].dropna()
    y_pm25 = merged.loc[X.index, "PM2.5"]
    y_pm10 = merged.loc[X.index, "PM10"]

    X_train25, X_test25, y_train25, y_test25 = train_test_split(
        X, y_pm25, test_size=0.2, random_state=42
    )
    X_train10, X_test10, y_train10, y_test10 = train_test_split(
        X, y_pm10, test_size=0.2, random_state=42
    )

    rf_pm25 = RandomForestRegressor(n_estimators=100, random_state=42)
    rf_pm10 = RandomForestRegressor(n_estimators=100, random_state=42)
    rf_pm25.fit(X_train25, y_train25)
    rf_pm10.fit(X_train10, y_train10)

    rmse_pm25 = mean_squared_error(y_test25, rf_pm25.predict(X_test25)) ** 0.5
    rmse_pm10 = mean_squared_error(y_test10, rf_pm10.predict(X_test10)) ** 0.5
    log.info("PM2.5 RMSE: %.3f | PM10 RMSE: %.3f", rmse_pm25, rmse_pm10)

    joblib.dump(rf_pm25, os.path.join(out_dir, "rf_pm25_model.joblib"))
    joblib.dump(rf_pm10, os.path.join(out_dir, "rf_pm10_model.joblib"))
    return rmse_pm25, rmse_pm10


def cluster_stations(merged, out_dir):
    from sklearn.cluster import KMeans

    cluster_features = ["Latitude", "Longitude", "PM2.5", "PM10"]
    X_cluster = merged[cluster_features].dropna()
    n_clusters = min(5, len(X_cluster)) or 1
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    clusters = kmeans.fit_predict(X_cluster)

    clustered = merged.loc[X_cluster.index].copy()
    clustered["Cluster"] = clusters
    clustered.to_csv(os.path.join(out_dir, "kmeans_cluster_output.csv"), index=False)
    log.info("KMeans clustering done (%d clusters), saved to kmeans_cluster_output.csv", n_clusters)
    return clustered


def run_q_learning_demo(merged, out_dir):
    avg_pm25 = merged["PM2.5"].mean()
    q_table = np.zeros((101, 101))
    alpha, gamma = 0.1, 0.9
    for _ in range(1000):
        state = np.random.randint(0, 101)
        action = np.random.randint(0, 101)
        reward = -avg_pm25 * (1 - (action + state) / 200)
        q_table[state, action] += alpha * (reward + gamma * np.max(q_table))

    np.save(os.path.join(out_dir, "q_table.npy"), q_table)
    optimal_nox, optimal_co = np.unravel_index(q_table.argmax(), q_table.shape)
    log.info("Q-learning demo: optimal NOx reduction %d%%, CO reduction %d%%", optimal_nox, optimal_co)


def run_prophet_forecast(merged, out_dir, target_col, periods=30):
    try:
        from prophet import Prophet
    except ImportError:
        log.warning("prophet not installed — skipping forecast for %s (pip install prophet)", target_col)
        return None

    if "From Date" not in merged.columns or target_col not in merged.columns:
        log.warning("Skipping %s forecast — required columns missing", target_col)
        return None

    df = merged[["From Date", target_col, "RH_MERRA"]].copy()
    df.rename(columns={"From Date": "ds", target_col: "y", "RH_MERRA": "RH"}, inplace=True)
    df.dropna(subset=["ds", "y", "RH"], inplace=True)
    if len(df) < 10:
        log.warning("Not enough rows to fit Prophet for %s — skipping", target_col)
        return None

    df["ds"] = pd.to_datetime(df["ds"])
    df = df.sort_values("ds")

    model = Prophet(yearly_seasonality=True, weekly_seasonality=True, daily_seasonality=False)
    model.add_regressor("RH")
    model.fit(df)

    future = model.make_future_dataframe(periods=periods)
    future["RH"] = df["RH"].iloc[-1]
    forecast = model.predict(future)

    out_path = os.path.join(out_dir, f"{target_col.replace('.', '')}_prophet_forecast.csv")
    forecast.to_csv(out_path, index=False)
    log.info("Saved %s forecast to %s", target_col, out_path)
    return forecast


def export_to_mongo(merged, collection="aqi_data"):
    """Optional: export the final dataset to MongoDB.
    Reads the connection string from the MONGODB_URI environment variable —
    never hardcode credentials in source files."""
    uri = os.environ.get("MONGODB_URI")
    if not uri:
        log.info("MONGODB_URI not set — skipping Mongo export (set it to enable this step)")
        return
    try:
        from pymongo import MongoClient
        client = MongoClient(uri)
        db = client.get_default_database()
        db[collection].insert_many(merged.to_dict("records"))
        log.info("Exported %d rows to MongoDB collection '%s'", len(merged), collection)
    except Exception as e:
        log.error("Mongo export failed: %s", e)


def main():
    parser = argparse.ArgumentParser(description="AQI Prediction Pipeline")
    parser.add_argument("--data-dir", default="./data", help="Folder containing CPCB.csv, INSAT_3DR.csv, MERRA_NASA.csv")
    parser.add_argument("--out-dir", default="./outputs", help="Folder to write models/forecasts/cluster outputs")
    parser.add_argument("--skip-prophet", action="store_true", help="Skip the Prophet forecasting step")
    parser.add_argument("--export-mongo", action="store_true", help="Export final dataset to MongoDB (needs MONGODB_URI env var)")
    args = parser.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)

    cpcb, insat, merra = load_inputs(args.data_dir)
    merged = merge_datasets(cpcb, insat, merra)
    merged = clean_and_engineer(merged)

    merged_path = os.path.join(args.out_dir, "final_ml_dataset.csv")
    merged.to_csv(merged_path, index=False)
    log.info("Saved merged dataset to %s", merged_path)

    train_models(merged, args.out_dir)
    cluster_stations(merged, args.out_dir)
    run_q_learning_demo(merged, args.out_dir)

    if not args.skip_prophet:
        run_prophet_forecast(merged, args.out_dir, "PM2.5")
        run_prophet_forecast(merged, args.out_dir, "PM10")

    if args.export_mongo:
        export_to_mongo(merged)

    log.info("Pipeline complete. Outputs in %s", args.out_dir)


if __name__ == "__main__":
    sys.exit(main())
