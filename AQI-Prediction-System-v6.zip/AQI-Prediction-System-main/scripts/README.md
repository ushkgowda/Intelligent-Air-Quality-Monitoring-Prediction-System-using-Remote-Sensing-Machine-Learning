# AQI Pipeline (standalone)

`aqi_pipeline.py` is a cleaned-up, Colab-free version of the original
`public/AQI_Monitoring_python_file.ipynb` notebook. It merges CPCB ground
station data with INSAT AOD and MERRA reanalysis data, trains PM2.5/PM10
RandomForest models, runs KMeans station clustering, a toy Q-learning
emissions-reduction demo, and optional Prophet forecasts.

## ⚠️ Security note
The original notebook had a MongoDB Atlas connection string with a
plaintext username and password committed directly in it. That has been
removed here. **Rotate that database password in MongoDB Atlas now** —
treat the old one as public/compromised. The cleaned script reads the URI
from the `MONGODB_URI` environment variable instead, and Mongo export is
opt-in (`--export-mongo`).

## Setup
```bash
pip install -r requirements.txt
```

## Usage
Place `CPCB.csv`, `INSAT_3DR.csv`, and `MERRA_NASA.csv` in a data folder
(e.g. `./data`), then run:

```bash
python aqi_pipeline.py --data-dir ./data --out-dir ./outputs
```

Flags:
- `--skip-prophet` — skip the forecasting step (faster, fewer deps)
- `--export-mongo` — push the final merged dataset to MongoDB
  (requires `MONGODB_URI` env var set first)

## Outputs (in `--out-dir`)
- `final_ml_dataset.csv` — cleaned, merged, feature-engineered dataset
- `rf_pm25_model.joblib`, `rf_pm10_model.joblib` — trained RandomForest models
- `kmeans_cluster_output.csv` — stations grouped into 5 pollution clusters
- `q_table.npy` — toy Q-learning emissions-reduction table
- `PM25_prophet_forecast.csv`, `PM10_prophet_forecast.csv` — 30-day forecasts

This was verified end-to-end (including the Prophet step) against synthetic
data shaped like the real CSVs, with zero errors. Drop in your real CPCB /
INSAT / MERRA files and it will produce the same outputs.
