import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const AQIDashboard = () => {
  const [aqiData, setAqiData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [userCity, setUserCity] = useState('');
  const [indianCitiesAqi, setIndianCitiesAqi] = useState([]);
  const [showAllCities, setShowAllCities] = useState(false);

  const indianCities = [
    'Mumbai', 'Delhi', 'Bengaluru', 'Hyderabad', 'Ahmedabad', 
    'Chennai', 'Kolkata', 'Surat', 'Pune', 'Jaipur',
    'Lucknow', 'Kanpur', 'Nagpur', 'Indore', 'Thane',
    'Bhopal', 'Visakhapatnam', 'Pimpri-Chinchwad', 'Patna', 'Vadodara',
    'Ghaziabad', 'Ludhiana', 'Agra', 'Nashik', 'Faridabad',
    'Meerut', 'Rajkot', 'Kalyan-Dombivli', 'Vasai-Virar', 'Varanasi',
    'Srinagar', 'Aurangabad', 'Dhanbad', 'Amritsar', 'Navi Mumbai',
    'Allahabad', 'Howrah', 'Gwalior', 'Jabalpur', 'Coimbatore',
    'Vijayawada', 'Jodhpur', 'Madurai', 'Raipur', 'Kota',
    'Guwahati', 'Chandigarh', 'Solapur', 'Hubli', 'Bareilly',
    'Moradabad', 'Mysore', 'Tiruchirappalli', 'Gurgaon', 'Aligarh',
    'Jalandhar', 'Bhubaneswar', 'Salem', 'Mira-Bhayandar', 'Warangal',
    'Guntur', 'Bhiwandi', 'Saharanpur', 'Gorakhpur', 'Bikaner',
    'Amravati', 'Noida', 'Jamshedpur', 'Bhilai', 'Cuttack',
    'Firozabad', 'Kochi', 'Nellore', 'Bhavnagar', 'Dehradun',
    'Durgapur', 'Asansol', 'Rourkela', 'Nanded', 'Kolhapur',
    'Ajmer', 'Akola', 'Gulbarga', 'Jamnagar', 'Ujjain',
    'Loni', 'Siliguri', 'Jhansi', 'Ulhasnagar', 'Jammu',
    'Mangalore', 'Erode', 'Belgaum', 'Kurnool', 'Tirunelveli',
    'Malegaon', 'Gaya', 'Udaipur', 'Davanagere', 'Tirupati'
  ];

  useEffect(() => {
    const fetchUserLocation = async () => {
      try {
        const ipResponse = await fetch('https://ipapi.co/json/');
        const ipData = await ipResponse.json();
        setUserCity(ipData.city);
        fetchAQIData(ipData.city);
      } catch (err) {
        fetchAQIData('Delhi');
      }
    };
    
    const fetchIndianCitiesAQI = async () => {
      try {
        const promises = indianCities.map(city => 
          fetch(`https://api.waqi.info/feed/${encodeURIComponent(city)}/?token=4651f75d4b06d6af245ca5dee7e45334373e3b4d`)
            .then(response => response.json())
            .then(data => ({
              city: city,
              data: data.status === 'ok' ? data.data : null
            }))
            .catch(() => ({
              city: city,
              data: null
            }))
        );

        const results = await Promise.all(promises);
        const validCities = results
          .filter(result => result.data && result.data.aqi !== '-')
          .sort((a, b) => b.data.aqi - a.data.aqi);
        
        setIndianCitiesAqi(validCities);
      } catch (err) {
        console.error('Error fetching Indian cities AQI:', err);
      }
    };
    
    fetchUserLocation();
    fetchIndianCitiesAQI();
  }, []);

  const fetchAQIData = async (city) => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(
        `https://api.waqi.info/feed/${encodeURIComponent(city)}/?token=4651f75d4b06d6af245ca5dee7e45334373e3b4d`
      );
      const data = await response.json();
      if (data.status !== 'ok') throw new Error(data.data || 'Unable to get air quality data');
      setAqiData(data.data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const getAqiQuality = (aqi) => {
    if (!aqi || aqi === '-') return {
      text: 'No Data',
      color: '#9E9E9E',
      textColor: '#ffffff',
      icon: '❓',
      bgColor: '#9E9E9E',
      lightBg: '#f5f5f5',
      advice: 'Air quality data not available for this location.'
    };
    
    const aciValue = parseInt(aqi);
    
    if (aciValue <= 50) {
      return {
        text: 'Good',
        color: '#4CAF50',
        textColor: '#ffffff',
        icon: '😊',
        bgColor: '#4CAF50',
        lightBg: '#E8F5E9',
        advice: `Air quality is excellent. It's perfect time to enjoy outdoors!

✅ Do:
• Go for walks, jogs, or cycling
• Keep windows and doors open
• Encourage outdoor activities

❌ Don't:
• Overlook indoor air quality
• Burn waste or biomass`
      };
    } else if (aciValue <= 100) {
      return {
        text: 'Moderate',
        color: '#FFC107',
        textColor: '#ffffff',
        icon: '😐',
        bgColor: '#FFC107',
        lightBg: '#FFF9C4',
        advice: `Air quality is acceptable, but sensitive groups may experience discomfort.

✅ Do:
• Go out during early morning/evening
• Monitor respiratory symptoms
• Use indoor air purifiers

❌ Don't:
• Exercise intensely outdoors
• Let children stay outside long`
      };
    } else if (aciValue <= 150) {
      return {
        text: 'Unhealthy',
        color: '#FF9800',
        textColor: '#ffffff',
        icon: '😷',
        bgColor: '#FF9800',
        lightBg: '#FFE0B2',
        advice: `Air quality is unhealthy. Sensitive groups may experience health effects.

✅ Do:
• Wear a mask if going out
• Use air purifiers indoors
• Limit outdoor time significantly

❌ Don't:
• Let kids/seniors play outside
• Keep windows open during peak hours`
      };
    } else if (aciValue <= 200) {
      return {
        text: 'Very Unhealthy',
        color: '#F44336',
        textColor: '#ffffff',
        icon: '😨',
        bgColor: '#F44336',
        lightBg: '#FFEBEE',
        advice: `Serious health risks! Everyone should limit outdoor activity.

✅ Do:
• Stay indoors with windows closed
• Use N95 masks if stepping out
• Keep medications ready

❌ Don't:
• Let anyone go outside
• Light candles or cook with poor ventilation`
      };
    } else {
      return {
        text: 'Hazardous',
        color: '#880E4F',
        textColor: '#ffffff',
        icon: '☠️',
        bgColor: '#880E4F',
        lightBg: '#FCE4EC',
        advice: `Health emergency! Limit all outdoor exposure completely.

✅ Do:
• Stay completely indoors
• Seal windows and doors
• Use HEPA air purifiers

❌ Don't:
• Venture outside unless absolutely necessary
• Use vehicles unnecessarily`
      };
    }
  };

  return (
    <div className="dashboard-wrapper">
      {/* Animated Background */}
      <div className="animated-bg">
        <div className="bg-circle bg-circle-1"></div>
        <div className="bg-circle bg-circle-2"></div>
        <div className="bg-circle bg-circle-3"></div>
        <div className="bg-circle bg-circle-4"></div>
      </div>

      <AnimatePresence>
        {loading && (
          <motion.div 
            className="loading-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <div className="loader"></div>
            <p>Loading air quality data...</p>
          </motion.div>
        )}
      </AnimatePresence>

      {error && (
        <motion.div 
          className="error-box"
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
        >
          <div className="error-text">⚠️ {error}</div>
          <button className="retry-btn" onClick={() => fetchAQIData(userCity || 'Delhi')}>Retry</button>
        </motion.div>
      )}

      {aqiData && !loading && (
        <motion.div className="container" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          {/* Location Info Banner */}
          <motion.div 
            className="location-banner"
            style={{ backgroundColor: getAqiQuality(aqiData.aqi).bgColor }}
            initial={{ y: -30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
          >
            <div className="location-left">
              <motion.span 
                className="location-pin"
                animate={{ y: [0, -8, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                📍
              </motion.span>
              <div className="location-text">
                <h2>{aqiData.city.name}</h2>
                <p>{new Date(aqiData.time.iso).toLocaleDateString()}</p>
              </div>
            </div>
            <div className="location-right">
              <span className="quality-label">Dominant Pollutant:</span>
              <span className="quality-value">
                {Object.keys(aqiData.iaqi).length > 0 
                  ? Object.keys(aqiData.iaqi)[0].toUpperCase() 
                  : 'N/A'}
              </span>
            </div>
          </motion.div>

          {/* Main AQI Display */}
          <motion.div 
            className="main-aqi-box"
            style={{ borderTop: `5px solid ${getAqiQuality(aqiData.aqi).bgColor}` }}
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <div className="aqi-box-content">
              <motion.div 
                className="aqi-emoji"
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                {getAqiQuality(aqiData.aqi).icon}
              </motion.div>
              <div className="aqi-number">{aqiData.aqi}</div>
              <div className="aqi-status">{getAqiQuality(aqiData.aqi).text}</div>
              
              <div className="aqi-gauge">
                <div className="gauge-scale">
                  <motion.div 
                    className="gauge-fill"
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min(100, (aqiData.aqi / 300) * 100)}%` }}
                    transition={{ delay: 0.4, duration: 1 }}
                    style={{ backgroundColor: getAqiQuality(aqiData.aqi).bgColor }}
                  />
                </div>
                <div className="gauge-labels">
                  <span>0</span>
                  <span>50</span>
                  <span>100</span>
                  <span>150</span>
                  <span>200+</span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Pollutants Grid */}
          <motion.div 
            className="pollutants-section"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <h3 className="section-title">Pollutants Concentration</h3>
            <div className="pollutants-grid">
              {Object.entries(aqiData.iaqi).map(([code, data], idx) => (
                <motion.div 
                  key={code} 
                  className="pollutant-card"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.05 * idx }}
                  whileHover={{ y: -5 }}
                >
                  <div className="pollutant-value">{data.v.toFixed(2)}</div>
                  <div className="pollutant-unit">
                    {code === 'pm25' || code === 'pm10' ? 'µg/m³' : code === 'dew' ? '°C' : code === 'h' ? '%' : code === 't' ? '°C' : 'ppb'}
                  </div>
                  <div className="pollutant-label">
                    {code === 'pm25' ? 'PM2.5' : 
                     code === 'pm10' ? 'PM10' : 
                     code === 'no2' ? 'NO₂' : 
                     code === 'o3' ? 'O₃' : 
                     code === 'so2' ? 'SO₂' : 
                     code === 'dew' ? 'DEW' :
                     code === 'h' ? 'HUMIDITY' :
                     code === 't' ? 'TEMP' :
                     code === 'p' ? 'PRESSURE' :
                     code === 'co' ? 'CO' :
                     code === 'wc' ? 'WIND CHILL' :
                     code === 'w' ? 'WIND' : code}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Health Advice */}
          <motion.div 
            className="advice-section"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            <h3 className="section-title">Health Advice</h3>
            <div className="advice-box">
              <div className="advice-content">
                {getAqiQuality(aqiData.aqi).advice}
              </div>
            </div>
          </motion.div>

          {/* Cities Grid */}
          <motion.div 
            className="cities-section"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <h3 className="section-title">Major Indian Cities</h3>
            <div className="cities-grid">
              {indianCitiesAqi.slice(0, showAllCities ? indianCitiesAqi.length : 12).map((cityData, idx) => {
                const quality = getAqiQuality(cityData.data.aqi);
                return (
                  <motion.div
                    key={idx}
                    className="city-card"
                    style={{ 
                      borderTop: `3px solid ${quality.bgColor}`,
                      backgroundColor: quality.lightBg
                    }}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: idx * 0.02 }}
                    whileHover={{ y: -4 }}
                  >
                    <div className="city-name">{cityData.city}</div>
                    <div className="city-aqi-val" style={{ color: quality.bgColor }}>
                      {cityData.data.aqi}
                    </div>
                    <div className="city-status" style={{ color: quality.bgColor }}>
                      {quality.text}
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {indianCitiesAqi.length > 12 && (
              <motion.button 
                className="show-more-btn"
                onClick={() => setShowAllCities(!showAllCities)}
                whileHover={{ scale: 1.02 }}
              >
                {showAllCities ? '← Show Less' : `Show All ${indianCitiesAqi.length} Cities →`}
              </motion.button>
            )}
          </motion.div>
        </motion.div>
      )}

      <style jsx>{`
        * { box-sizing: border-box; }

        .dashboard-wrapper {
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          min-height: 100vh;
          padding: 1.5rem;
          color: #333;
          position: relative;
          overflow-x: hidden;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 25%, #f093fb 50%, #4facfe 75%, #00f2fe 100%);
          background-size: 400% 400%;
          animation: gradientAnimation 15s ease infinite;
        }

        @keyframes gradientAnimation {
          0% { 
            background-position: 0% 50%;
          }
          50% { 
            background-position: 100% 50%;
          }
          100% { 
            background-position: 0% 50%;
          }
        }

        /* Animated Background Circles */
        .animated-bg {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          z-index: -1;
          overflow: hidden;
        }

        .bg-circle {
          position: absolute;
          border-radius: 50%;
          filter: blur(80px);
          opacity: 0.2;
        }

        .bg-circle-1 {
          width: 400px;
          height: 400px;
          background: rgba(255, 255, 255, 0.5);
          top: -100px;
          left: -100px;
          animation: float 20s infinite ease-in-out;
        }

        .bg-circle-2 {
          width: 300px;
          height: 300px;
          background: rgba(255, 255, 255, 0.4);
          bottom: -50px;
          right: -50px;
          animation: float 25s infinite ease-in-out reverse;
        }

        .bg-circle-3 {
          width: 350px;
          height: 350px;
          background: rgba(255, 255, 255, 0.3);
          top: 50%;
          left: 50%;
          animation: float 30s infinite ease-in-out;
        }

        .bg-circle-4 {
          width: 280px;
          height: 280px;
          background: rgba(255, 255, 255, 0.35);
          bottom: 20%;
          left: 10%;
          animation: float 22s infinite ease-in-out reverse;
        }

        @keyframes float {
          0%, 100% { 
            transform: translate(0, 0);
          }
          33% { 
            transform: translate(30px, -30px);
          }
          66% { 
            transform: translate(-20px, 20px);
          }
        }

        .loading-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.6);
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          z-index: 9999;
          backdrop-filter: blur(4px);
        }

        .loader {
          width: 50px;
          height: 50px;
          border: 4px solid rgba(255, 255, 255, 0.3);
          border-top-color: white;
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }

        @keyframes spin {
          to { transform: rotate(360deg); }
        }

        .loading-overlay p {
          color: white;
          margin-top: 1.5rem;
          font-size: 1rem;
          font-weight: 500;
        }

        .error-box {
          max-width: 600px;
          margin: 1.5rem auto;
          background: #fff3cd;
          border-left: 4px solid #ff9800;
          padding: 1.5rem;
          border-radius: 8px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          position: relative;
          z-index: 10;
          box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .error-text {
          flex: 1;
          color: #856404;
          font-weight: 500;
        }

        .retry-btn {
          background: #ff9800;
          color: white;
          border: none;
          padding: 0.6rem 1.2rem;
          border-radius: 6px;
          cursor: pointer;
          font-weight: 600;
          transition: all 0.3s;
        }

        .retry-btn:hover {
          background: #e68900;
          transform: translateY(-2px);
        }

        .container {
          max-width: 1200px;
          margin: 0 auto;
          position: relative;
          z-index: 5;
        }

        /* Location Banner */
        .location-banner {
          color: white;
          padding: 1.5rem;
          border-radius: 12px;
          margin-bottom: 1.5rem;
          display: flex;
          justify-content: space-between;
          align-items: center;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
          border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .location-left {
          display: flex;
          align-items: center;
          gap: 1rem;
        }

        .location-pin {
          font-size: 2rem;
          display: block;
        }

        .location-text h2 {
          margin: 0;
          font-size: 1.5rem;
          font-weight: 600;
        }

        .location-text p {
          margin: 0.3rem 0 0;
          font-size: 0.9rem;
          opacity: 0.9;
        }

        .location-right {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          gap: 0.3rem;
        }

        .quality-label {
          font-size: 0.85rem;
          opacity: 0.9;
        }

        .quality-value {
          font-size: 1.2rem;
          font-weight: 700;
          background: rgba(255, 255, 255, 0.25);
          padding: 0.4rem 0.8rem;
          border-radius: 6px;
        }

        /* Main AQI Box */
        .main-aqi-box {
          background: white;
          border-radius: 12px;
          padding: 2.5rem;
          margin-bottom: 2rem;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
          text-align: center;
        }

        .aqi-box-content {
          display: flex;
          flex-direction: column;
          align-items: center;
        }

        .aqi-emoji {
          font-size: 4rem;
          margin-bottom: 1rem;
          display: block;
        }

        .aqi-number {
          font-size: 4.5rem;
          font-weight: 800;
          margin-bottom: 0.5rem;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .aqi-status {
          font-size: 1.5rem;
          font-weight: 600;
          color: #555;
          margin-bottom: 1.5rem;
        }

        .aqi-gauge {
          width: 100%;
          max-width: 500px;
        }

        .gauge-scale {
          height: 12px;
          background: #e0e0e0;
          border-radius: 6px;
          overflow: hidden;
          margin-bottom: 0.8rem;
        }

        .gauge-fill {
          height: 100%;
          border-radius: 6px;
          box-shadow: 0 0 10px rgba(102, 126, 234, 0.4);
        }

        .gauge-labels {
          display: flex;
          justify-content: space-between;
          font-size: 0.8rem;
          color: #999;
        }

        /* Pollutants Section */
        .pollutants-section {
          background: rgba(255, 255, 255, 0.98);
          border-radius: 12px;
          padding: 2rem;
          margin-bottom: 2rem;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .section-title {
          margin: 0 0 1.5rem 0;
          font-size: 1.4rem;
          font-weight: 600;
          color: #333;
          padding-bottom: 1rem;
          border-bottom: 2px solid #f0f0f0;
        }

        .pollutants-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
          gap: 1.2rem;
        }

        .pollutant-card {
          background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
          padding: 1.5rem;
          border-radius: 10px;
          text-align: center;
          border: 1px solid #ddd;
          transition: all 0.3s;
          cursor: pointer;
        }

        .pollutant-card:hover {
          transform: translateY(-4px);
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.12);
        }

        .pollutant-value {
          font-size: 1.8rem;
          font-weight: 700;
          color: #333;
          margin-bottom: 0.3rem;
        }

        .pollutant-unit {
          font-size: 0.8rem;
          color: #666;
          margin-bottom: 0.5rem;
          display: block;
        }

        .pollutant-label {
          font-size: 0.75rem;
          color: #555;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        /* Health Advice */
        .advice-section {
          background: rgba(255, 255, 255, 0.98);
          border-radius: 12px;
          padding: 2rem;
          margin-bottom: 2rem;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .advice-box {
          background: #f9f9f9;
          padding: 1.5rem;
          border-radius: 8px;
          border-left: 4px solid #667eea;
        }

        .advice-content {
          font-size: 0.95rem;
          line-height: 1.7;
          color: #555;
          white-space: pre-wrap;
          word-break: break-word;
        }

        /* Cities Section */
        .cities-section {
          background: rgba(255, 255, 255, 0.98);
          border-radius: 12px;
          padding: 2rem;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .cities-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
          gap: 1rem;
          margin-bottom: 1.5rem;
        }

        .city-card {
          padding: 1.5rem;
          border-radius: 10px;
          text-align: center;
          border: 1px solid #ddd;
          transition: all 0.3s;
          cursor: pointer;
        }

        .city-card:hover {
          transform: translateY(-6px);
          box-shadow: 0 12px 35px rgba(0, 0, 0, 0.15);
        }

        .city-name {
          font-size: 0.95rem;
          font-weight: 600;
          color: #333;
          margin-bottom: 0.8rem;
          word-break: break-word;
        }

        .city-aqi-val {
          font-size: 2.5rem;
          font-weight: 800;
          margin-bottom: 0.5rem;
        }

        .city-status {
          font-size: 0.85rem;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .show-more-btn {
          width: 100%;
          padding: 1rem;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          border: none;
          border-radius: 10px;
          font-size: 1rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s;
          box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
        }

        .show-more-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 12px 30px rgba(102, 126, 234, 0.4);
        }

        /* Responsive */
        @media (max-width: 768px) {
          .location-banner {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
          }

          .location-right {
            align-items: flex-start;
          }

          .aqi-number {
            font-size: 3.5rem;
          }

          .aqi-emoji {
            font-size: 3rem;
          }

          .pollutants-grid {
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
          }

          .cities-grid {
            grid-template-columns: repeat(auto-fill, minmax(130px, 1fr));
          }
        }

        @media (max-width: 480px) {
          .dashboard-wrapper {
            padding: 1rem 0.75rem;
          }

          .main-aqi-box {
            padding: 1.5rem;
            margin-bottom: 1rem;
          }

          .aqi-number {
            font-size: 3rem;
          }

          .aqi-emoji {
            font-size: 2.5rem;
          }

          .pollutants-section,
          .advice-section,
          .cities-section {
            padding: 1.5rem;
            margin-bottom: 1.5rem;
          }

          .pollutants-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 0.8rem;
          }

          .cities-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 0.8rem;
          }

          .section-title {
            font-size: 1.2rem;
          }

          .location-pin {
            font-size: 1.5rem;
          }

          .location-text h2 {
            font-size: 1.2rem;
          }
        }
      `}</style>
    </div>
  );
};

export default AQIDashboard;
