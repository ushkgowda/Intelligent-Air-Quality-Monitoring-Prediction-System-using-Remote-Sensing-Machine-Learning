import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';

const T = {
  bg: '#16202c',
  border: 'rgba(255,255,255,0.08)',
  text: '#f0f4f8',
  textSub: '#8fafc9',
  accent: '#3b82f6',
  fontDisplay: "'Space Grotesk', sans-serif",
  fontMono: "'IBM Plex Mono', monospace",
};

const LINKS = [
  { to: '/', label: 'Dashboard' },
  { to: '/live', label: '🔴 Live Map' },
  { to: '/health', label: '☣️ Health & VOC' },
  { to: '/AQITables', label: 'AQI Rankings' },
  { to: '/AQITables2', label: 'PM2.5 Data' },
  { to: '/AirPrevData', label: 'Historical' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => setMenuOpen(false), [location.pathname]);

  return (
    <nav style={{
      position: 'sticky',
      top: 0,
      zIndex: 1000,
      background: T.bg,
      borderBottom: `1px solid ${scrolled ? 'rgba(59,130,246,0.25)' : T.border}`,
      boxShadow: scrolled ? '0 2px 16px rgba(0,0,0,0.35)' : 'none',
      transition: 'box-shadow 0.2s, border-color 0.2s',
    }}>
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 32px',
        height: 56,
        maxWidth: 1440,
        margin: '0 auto',
      }}>
        {/* Logo */}
        <Link to="/" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 32, height: 32, borderRadius: 8,
            background: 'linear-gradient(135deg, #1d4ed8 0%, #3b82f6 100%)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: T.fontDisplay, fontWeight: 700, fontSize: 13, color: '#fff',
          }}>IN</div>
          <span style={{ fontFamily: T.fontDisplay, fontWeight: 700, fontSize: 18, color: T.text, letterSpacing: '-0.01em' }}>AQ-INDIA</span>
        </Link>

        {/* Desktop links */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          {LINKS.map(({ to, label }) => {
            const active = location.pathname === to;
            return (
              <Link
                key={to}
                to={to}
                style={{
                  fontFamily: T.fontDisplay,
                  fontSize: 14,
                  fontWeight: active ? 700 : 500,
                  color: active ? '#fff' : T.textSub,
                  textDecoration: 'none',
                  padding: '6px 14px',
                  borderRadius: 8,
                  background: active ? 'rgba(59,130,246,0.18)' : 'transparent',
                  border: active ? '1px solid rgba(59,130,246,0.35)' : '1px solid transparent',
                  transition: 'all 0.15s',
                }}
              >{label}</Link>
            );
          })}
        </div>

        {/* Right badge */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{
            fontFamily: T.fontMono,
            fontSize: 11,
            color: '#3aa757',
            padding: '3px 10px',
            borderRadius: 99,
            background: 'rgba(58,167,87,0.12)',
            border: '1px solid rgba(58,167,87,0.3)',
            display: 'flex',
            alignItems: 'center',
            gap: 6,
          }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#3aa757', display: 'inline-block' }} />
            CPCB Standard
          </span>
        </div>
      </div>
    </nav>
  );
}
