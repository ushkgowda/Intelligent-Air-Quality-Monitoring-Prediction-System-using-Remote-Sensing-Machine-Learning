import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Tooltip,
} from 'chart.js';
import { aqiCategory } from '../utils/aqiData';

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip);

export default function StateRankingChart({ states, topN = 15, onStateClick }) {
  const slice = states.slice(0, topN);
  const labels = slice.map((s) => s.state);
  const values = slice.map((s) => s.avgAqi);
  const colors = slice.map((s) => aqiCategory(s.avgAqi).color);

  const data = {
    labels,
    datasets: [
      {
        label: 'Avg AQI',
        data: values,
        backgroundColor: colors.map((c) => c + 'cc'),
        borderColor: colors,
        borderWidth: 1.5,
        borderRadius: 4,
      },
    ],
  };

  const options = {
    indexAxis: 'y',
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#16202c',
        titleFont: { family: "'Space Grotesk', sans-serif" },
        bodyFont: { family: "'IBM Plex Mono', monospace" },
        callbacks: {
          label: (ctx) => {
            const state = states[ctx.dataIndex];
            return ` AQI ${ctx.raw}  ·  PM2.5 ${state.avgPm25} μg/m³`;
          },
        },
      },
    },
    scales: {
      x: {
        grid: { color: 'rgba(148,163,184,0.15)' },
        ticks: { font: { family: "'IBM Plex Mono', monospace", size: 11 }, color: '#5b6b7c' },
      },
      y: {
        grid: { display: false },
        ticks: { font: { family: "'Inter', sans-serif", size: 12 }, color: '#2d3a47' },
      },
    },
  };

  const handleClick = (event, elements) => {
    if (elements.length > 0 && onStateClick) {
      onStateClick(slice[elements[0].index].state);
    }
  };

  return (
    <div style={{ height: Math.max(320, slice.length * 28) }}>
      <Bar data={data} options={options} onClick={handleClick} />
    </div>
  );
}
