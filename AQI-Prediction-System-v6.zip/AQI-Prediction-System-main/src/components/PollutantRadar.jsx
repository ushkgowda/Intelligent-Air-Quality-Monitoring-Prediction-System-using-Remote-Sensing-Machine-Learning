import { Radar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(RadialLinearScale, PointElement, LineElement, Filler, Tooltip, Legend);

// Normalises each pollutant against a WHO/CPCB 24h reference limit so the
// radar axes are all "% of safe limit" instead of raw μg/m³ / ppm values.
const LIMITS = {
  'PM2.5': 60,
  'PM10': 100,
  'NO2': 80,
  'SO2': 80,
  'CO': 2,
  'Ozone': 100,
};

export default function PollutantRadar({ station }) {
  if (!station) return null;

  const pollutants = Object.keys(LIMITS);
  const values = pollutants.map((p) => {
    const raw = station[p.toLowerCase().replace('.', '').replace('2', '2')] ??
      station[p] ?? 0;
    return Math.min(200, Math.round((raw / LIMITS[p]) * 100));
  });

  const data = {
    labels: pollutants.map((p) => `${p}`),
    datasets: [
      {
        label: '% of safe limit',
        data: values,
        borderColor: '#1d4ed8',
        backgroundColor: 'rgba(29,78,216,0.15)',
        pointBackgroundColor: '#1d4ed8',
        pointRadius: 4,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#16202c',
        bodyFont: { family: "'IBM Plex Mono', monospace" },
        callbacks: {
          label: (ctx) => ` ${ctx.raw}% of safe limit`,
        },
      },
    },
    scales: {
      r: {
        min: 0,
        max: 200,
        ticks: { stepSize: 50, font: { family: "'IBM Plex Mono', monospace", size: 10 }, color: '#5b6b7c' },
        grid: { color: 'rgba(148,163,184,0.2)' },
        pointLabels: { font: { family: "'Inter', sans-serif", size: 12, weight: '600' }, color: '#2d3a47' },
      },
    },
  };

  return (
    <div style={{ height: 280 }}>
      <Radar data={data} options={options} />
    </div>
  );
}
