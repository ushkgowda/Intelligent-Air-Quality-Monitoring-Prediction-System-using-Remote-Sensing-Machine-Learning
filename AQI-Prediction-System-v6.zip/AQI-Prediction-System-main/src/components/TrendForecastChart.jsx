import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Filler,
} from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Filler);

export default function TrendForecastChart({ history, forecast, label }) {
  if (!history?.length) {
    return <div style={{ color: '#5b6b7c', fontFamily: "'Inter', sans-serif", padding: '24px 0' }}>No monthly history available for {label}.</div>;
  }

  const labels = [...history.map((h) => h.label), ...forecast.map((f) => f.label)];
  const historyData = [...history.map((h) => h.pm25), ...Array(forecast.length).fill(null)];
  // Bridge: forecast line should start at the last known historical point
  const forecastData = [
    ...Array(history.length - 1).fill(null),
    history[history.length - 1].pm25,
    ...forecast.map((f) => f.pm25),
  ];

  const data = {
    labels,
    datasets: [
      {
        label: 'Historical PM2.5 (μg/m³)',
        data: historyData,
        borderColor: '#1d4ed8',
        backgroundColor: 'rgba(29, 78, 216, 0.08)',
        fill: true,
        tension: 0.35,
        pointRadius: 4,
        pointBackgroundColor: '#1d4ed8',
      },
      {
        label: 'Forecast (linear trend)',
        data: forecastData,
        borderColor: '#f97316',
        borderDash: [6, 5],
        backgroundColor: 'rgba(249, 115, 22, 0.06)',
        fill: true,
        tension: 0.35,
        pointRadius: 4,
        pointBackgroundColor: '#f97316',
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    interaction: { mode: 'index', intersect: false },
    plugins: {
      legend: {
        position: 'bottom',
        labels: { font: { family: "'Inter', sans-serif", size: 12 }, color: '#3c4a59', usePointStyle: true },
      },
      tooltip: {
        backgroundColor: '#16202c',
        titleFont: { family: "'Space Grotesk', sans-serif" },
        bodyFont: { family: "'IBM Plex Mono', monospace" },
      },
    },
    scales: {
      x: { grid: { display: false }, ticks: { font: { family: "'IBM Plex Mono', monospace", size: 11 }, color: '#5b6b7c' } },
      y: {
        title: { display: true, text: 'PM2.5 (μg/m³)', font: { family: "'Inter', sans-serif", size: 12 }, color: '#5b6b7c' },
        grid: { color: 'rgba(148,163,184,0.18)' },
        ticks: { font: { family: "'IBM Plex Mono', monospace", size: 11 }, color: '#5b6b7c' },
      },
    },
  };

  return (
    <div style={{ height: 320 }}>
      <Line data={data} options={options} />
    </div>
  );
}
