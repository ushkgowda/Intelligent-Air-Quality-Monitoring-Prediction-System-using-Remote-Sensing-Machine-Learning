import { aqiCategory } from '../utils/aqiData';

// A radial instrument gauge -- the signature visual element of the dashboard.
// Reads like a physical air-quality meter: a fixed six-band coloured arc
// (the CPCB AQI scale) with a needle/value indicator for the current reading.
export default function AQIGauge({ value, label = 'National Average AQI', size = 260 }) {
  const cat = aqiCategory(value);
  const bands = [
    { upto: 50, color: '#3aa757' },
    { upto: 100, color: '#a3c853' },
    { upto: 200, color: '#f5c518' },
    { upto: 300, color: '#f97316' },
    { upto: 400, color: '#dc2626' },
    { upto: 500, color: '#7f1d1d' },
  ];

  const r = size / 2 - 18;
  const cx = size / 2;
  const cy = size / 2;
  const startAngle = -210;
  const endAngle = 30;
  const totalAngle = endAngle - startAngle;

  const angleFor = (v) => startAngle + (Math.min(v, 500) / 500) * totalAngle;
  const polar = (angleDeg, radius) => {
    const a = (angleDeg * Math.PI) / 180;
    return [cx + radius * Math.cos(a), cy + radius * Math.sin(a)];
  };

  const arcPath = (a0, a1, radius) => {
    const [x0, y0] = polar(a0, radius);
    const [x1, y1] = polar(a1, radius);
    const large = a1 - a0 > 180 ? 1 : 0;
    return `M ${x0} ${y0} A ${radius} ${radius} 0 ${large} 1 ${x1} ${y1}`;
  };

  let prevUpto = 0;
  const needleAngle = angleFor(value ?? 0);
  const [nx, ny] = polar(needleAngle, r - 6);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      <svg width={size} height={size * 0.72} viewBox={`0 0 ${size} ${size * 0.72}`}>
        {bands.map((b, i) => {
          const a0 = angleFor(prevUpto);
          const a1 = angleFor(b.upto);
          prevUpto = b.upto;
          return (
            <path
              key={i}
              d={arcPath(a0, a1, r)}
              stroke={b.color}
              strokeWidth={14}
              fill="none"
              strokeLinecap="butt"
              opacity={0.92}
            />
          );
        })}
        <line x1={cx} y1={cy} x2={nx} y2={ny} stroke="#1e2a3a" strokeWidth={3} strokeLinecap="round" />
        <circle cx={cx} cy={cy} r={7} fill="#1e2a3a" />
        <text x={cx} y={cy - 28} textAnchor="middle" fontFamily="'Space Grotesk', sans-serif" fontWeight="700" fontSize={size * 0.18} fill="#16202c">
          {value ?? '--'}
        </text>
        <text x={cx} y={cy - 4} textAnchor="middle" fontFamily="'Inter', sans-serif" fontWeight="600" fontSize={13} fill={cat.color}>
          {cat.label.toUpperCase()}
        </text>
      </svg>
      <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: '#5b6b7c', marginTop: 4, letterSpacing: '0.02em' }}>
        {label}
      </div>
    </div>
  );
}
