// WAQI live API integration (optional).
//
// The original file had an API token hardcoded here — treat that token as
// compromised and revoke it at https://aqicn.org/data-platform/token/
// To re-enable live data, set VITE_WAQI_TOKEN in a .env.local file:
//   VITE_WAQI_TOKEN=your_token_here
// Never commit tokens in source files.

import axios from 'axios';

const TOKEN = import.meta.env.VITE_WAQI_TOKEN || '';

export const getCityAQI = async (city) => {
  if (!TOKEN) {
    console.warn('WAQI token not set. Add VITE_WAQI_TOKEN to .env.local for live data.');
    return { data: { aqi: null } };
  }
  try {
    const res = await axios.get(`https://api.waqi.info/feed/${encodeURIComponent(city)}/?token=${TOKEN}`);
    return res.data;
  } catch (e) {
    console.error('AQI Fetch Error', e);
    return { data: { aqi: null } };
  }
};
