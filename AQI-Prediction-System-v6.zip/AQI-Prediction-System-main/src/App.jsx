import Navbar from './components/Navbar';
import AQIBot from './components/AQIBot';
import Dashboard from './pages/Dashboard';
import AQITables from './pages/AQITables';
import AQITables2 from './pages/AQITables2';
import AirPrevData from './pages/AirPrevData';
import LiveMap from './pages/LiveMap';
import HealthVOC from './pages/HealthVOC';
import { Routes, Route } from 'react-router-dom';

function App() {
  return (
    <>
      <Navbar />
      <AQIBot />
      <Routes>
        <Route path="/"           element={<Dashboard />} />
        <Route path="/live"       element={<LiveMap />} />
        <Route path="/health"     element={<HealthVOC />} />
        <Route path="/AQITables"  element={<AQITables />} />
        <Route path="/AQITables2" element={<AQITables2 />} />
        <Route path="/AirPrevData" element={<AirPrevData />} />
      </Routes>
    </>
  );
}

export default App;
