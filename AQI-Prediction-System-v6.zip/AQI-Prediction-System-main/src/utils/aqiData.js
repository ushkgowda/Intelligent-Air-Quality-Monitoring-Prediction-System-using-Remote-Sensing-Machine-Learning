// AQI utilities: loads the station dataset, converts PM2.5 -> Indian CPCB AQI,
// aggregates by city/state, and produces a short-term forecast using linear
// regression over the available historical points (this is a transparent
// statistical trend projection, not a live sensor feed or the trained
// RandomForest model from scripts/aqi_pipeline.py).

// CPCB PM2.5 sub-index breakpoints (India National AQI)
const PM25_BREAKPOINTS = [
  { cLo: 0, cHi: 30, iLo: 0, iHi: 50 },
  { cLo: 31, cHi: 60, iLo: 51, iHi: 100 },
  { cLo: 61, cHi: 90, iLo: 101, iHi: 200 },
  { cLo: 91, cHi: 120, iLo: 201, iHi: 300 },
  { cLo: 121, cHi: 250, iLo: 301, iHi: 400 },
  { cLo: 251, cHi: 500, iLo: 401, iHi: 500 },
];

export function pm25ToAQI(pm25) {
  if (pm25 == null || isNaN(pm25)) return null;
  const c = Math.max(0, pm25);
  const bp = PM25_BREAKPOINTS.find((b) => c >= b.cLo && c <= b.cHi) || PM25_BREAKPOINTS[PM25_BREAKPOINTS.length - 1];
  const aqi = ((bp.iHi - bp.iLo) / (bp.cHi - bp.cLo)) * (c - bp.cLo) + bp.iLo;
  return Math.round(aqi);
}

export function aqiCategory(aqi) {
  if (aqi == null) return { label: 'Unknown', color: '#94a3b8' };
  if (aqi <= 50) return { label: 'Good', color: '#3aa757' };
  if (aqi <= 100) return { label: 'Satisfactory', color: '#a3c853' };
  if (aqi <= 200) return { label: 'Moderate', color: '#f5c518' };
  if (aqi <= 300) return { label: 'Poor', color: '#f97316' };
  if (aqi <= 400) return { label: 'Very Poor', color: '#dc2626' };
  return { label: 'Severe', color: '#7f1d1d' };
}

export async function loadStations() {
  const res = await fetch('/aqi-data.json');
  if (!res.ok) throw new Error('Failed to load aqi-data.json');
  const raw = await res.json();
  return raw
    .filter((r) => r['PM2.5'] != null && r.State)
    .map((r) => ({
      state: r.State,
      station: r.Station,
      lat: r.Latitude,
      lon: r.Longitude,
      pm25: r['PM2.5'],
      pm10: r['PM10'],
      no2: r['NO2'],
      so2: r['SO2'],
      co: r['CO'],
      ozone: r['Ozone'],
      year: r.Year,
      month: r.Month,
      day: r.Day,
      date: r.Year && r.Month && r.Day ? new Date(r.Year, r.Month - 1, r.Day) : null,
      aqi: pm25ToAQI(r['PM2.5']),
    }));
}

export function aggregateByState(stations) {
  const byState = new Map();
  for (const s of stations) {
    if (!byState.has(s.state)) byState.set(s.state, []);
    byState.get(s.state).push(s);
  }
  return Array.from(byState.entries())
    .map(([state, rows]) => {
      const avgPm25 = rows.reduce((a, r) => a + r.pm25, 0) / rows.length;
      return {
        state,
        stationCount: rows.length,
        avgPm25: Math.round(avgPm25 * 10) / 10,
        avgAqi: pm25ToAQI(avgPm25),
      };
    })
    .sort((a, b) => b.avgAqi - a.avgAqi);
}

// Simple ordinary-least-squares linear regression: returns {slope, intercept}
function linearRegression(points) {
  const n = points.length;
  if (n < 2) return { slope: 0, intercept: points[0]?.y ?? 0 };
  const sumX = points.reduce((a, p) => a + p.x, 0);
  const sumY = points.reduce((a, p) => a + p.y, 0);
  const sumXY = points.reduce((a, p) => a + p.x * p.y, 0);
  const sumXX = points.reduce((a, p) => a + p.x * p.x, 0);
  const denom = n * sumXX - sumX * sumX;
  const slope = denom === 0 ? 0 : (n * sumXY - sumX * sumY) / denom;
  const intercept = (sumY - slope * sumX) / n;
  return { slope, intercept };
}

/**
 * Builds a monthly PM2.5 history for a state from the dataset, plus a
 * linear-trend forecast for the next `forecastMonths` months.
 */
export function getStateTrendAndForecast(stations, state, forecastMonths = 4) {
  const rows = stations.filter((s) => s.state === state && s.month);
  const byMonth = new Map();
  for (const r of rows) {
    const key = r.month;
    if (!byMonth.has(key)) byMonth.set(key, []);
    byMonth.get(key).push(r.pm25);
  }
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const history = Array.from(byMonth.entries())
    .map(([month, vals]) => ({
      month,
      label: monthNames[month - 1],
      pm25: Math.round((vals.reduce((a, v) => a + v, 0) / vals.length) * 10) / 10,
    }))
    .sort((a, b) => a.month - b.month);

  if (history.length === 0) return { history: [], forecast: [] };

  const points = history.map((h, i) => ({ x: i, y: h.pm25 }));
  const { slope, intercept } = linearRegression(points);

  const forecast = [];
  for (let i = 1; i <= forecastMonths; i++) {
    const x = history.length - 1 + i;
    const nextMonthIdx = (history[history.length - 1].month - 1 + i) % 12;
    const predicted = Math.max(0, slope * x + intercept);
    forecast.push({
      month: nextMonthIdx + 1,
      label: monthNames[nextMonthIdx],
      pm25: Math.round(predicted * 10) / 10,
      isForecast: true,
    });
  }

  return { history, forecast, trendSlope: slope };
}

export function nationalSummary(stations) {
  const avgPm25 = stations.reduce((a, r) => a + r.pm25, 0) / stations.length;
  const sorted = [...stations].sort((a, b) => b.pm25 - a.pm25);
  return {
    avgPm25: Math.round(avgPm25 * 10) / 10,
    avgAqi: pm25ToAQI(avgPm25),
    stationCount: stations.length,
    mostPolluted: sorted[0],
    cleanest: sorted[sorted.length - 1],
  };
}
