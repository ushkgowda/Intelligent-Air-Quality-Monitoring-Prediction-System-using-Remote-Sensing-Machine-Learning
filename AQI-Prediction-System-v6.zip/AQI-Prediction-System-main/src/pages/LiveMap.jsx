import { useState, useEffect, useCallback, useRef } from 'react';
import { MapContainer, TileLayer, CircleMarker, Popup, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { pm25ToAQI, aqiCategory } from '../utils/aqiData';

// ── Design tokens ────────────────────────────────────────────────────────────
const T = {
  bg: '#f0f4f8',
  surface: '#fff',
  border: 'rgba(148,163,184,0.28)',
  text: '#16202c',
  textSub: '#5b6b7c',
  accent: '#1d4ed8',
  accentLight: 'rgba(29,78,216,0.08)',
  fontDisplay: "'Space Grotesk', sans-serif",
  fontBody: "'Inter', sans-serif",
  fontMono: "'IBM Plex Mono', monospace",
  radius: '12px',
  shadow: '0 1px 4px rgba(0,0,0,0.07), 0 4px 16px rgba(0,0,0,0.05)',
};

// ── Haversine distance (km) between two lat/lon points ───────────────────────
function distKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// ── Find nearest N stations to a coordinate ──────────────────────────────────
function nearestStations(allStations, lat, lon, n = 5) {
  return allStations
    .map((s) => ({ ...s, distKm: distKm(lat, lon, s.lat, s.lon) }))
    .sort((a, b) => a.distKm - b.distKm)
    .slice(0, n);
}

// ── Fly to user on map ───────────────────────────────────────────────────────
function FlyTo({ lat, lng, zoom = 9 }) {
  const map = useMap();
  const didFly = useRef(false);
  useEffect(() => {
    if (lat && lng && !didFly.current) {
      map.flyTo([lat, lng], zoom, { duration: 1.4 });
      didFly.current = true;
    }
  }, [lat, lng]);
  return null;
}

// ── Reusable UI pieces ───────────────────────────────────────────────────────
function Card({ children, style = {} }) {
  return (
    <div style={{
      background: T.surface, borderRadius: T.radius,
      border: `1px solid ${T.border}`, boxShadow: T.shadow,
      padding: '24px', ...style,
    }}>{children}</div>
  );
}
function SLabel({ children }) {
  return (
    <div style={{
      fontFamily: T.fontMono, fontSize: 11, fontWeight: 600,
      letterSpacing: '0.12em', color: T.textSub,
      textTransform: 'uppercase', marginBottom: 10,
    }}>{children}</div>
  );
}
function CTitle({ children }) {
  return <h2 style={{ fontFamily: T.fontDisplay, fontWeight: 700, fontSize: 18, color: T.text, margin: '0 0 4px 0' }}>{children}</h2>;
}

// ── AQI circle indicator ─────────────────────────────────────────────────────
function AQICircle({ aqi, size = 140 }) {
  const cat = aqiCategory(aqi);
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      border: `6px solid ${aqi ? cat.color : T.border}`,
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      background: aqi ? cat.color + '11' : T.bg,
      boxShadow: aqi ? `0 0 32px ${cat.color}44` : 'none',
      transition: 'all 0.4s', flexShrink: 0,
    }}>
      <span style={{ fontFamily: T.fontDisplay, fontWeight: 700, fontSize: size * 0.31, color: aqi ? cat.color : T.textSub, lineHeight: 1 }}>
        {aqi ?? '--'}
      </span>
      <span style={{ fontFamily: T.fontMono, fontSize: 11, color: T.textSub }}>AQI</span>
    </div>
  );
}

// ── Small pollutant chip ─────────────────────────────────────────────────────
function Chip({ label, value, unit }) {
  if (value == null || isNaN(value)) return null;
  return (
    <div style={{
      background: T.bg, border: `1px solid ${T.border}`,
      borderRadius: 8, padding: '8px 14px', textAlign: 'center', minWidth: 76,
    }}>
      <div style={{ fontFamily: T.fontMono, fontSize: 10, color: T.textSub, textTransform: 'uppercase', letterSpacing: '0.08em' }}>{label}</div>
      <div style={{ fontFamily: T.fontDisplay, fontWeight: 700, fontSize: 18, color: T.text }}>{typeof value === 'number' ? value.toFixed(1) : value}</div>
      {unit && <div style={{ fontFamily: T.fontMono, fontSize: 10, color: T.textSub }}>{unit}</div>}
    </div>
  );
}

// ── AQI category badge ───────────────────────────────────────────────────────
function AQIBadge({ aqi }) {
  const cat = aqiCategory(aqi);
  return (
    <span style={{
      fontFamily: T.fontMono, fontSize: 11, fontWeight: 700,
      padding: '3px 10px', borderRadius: 99,
      background: cat.color + '22', color: cat.color,
      border: `1px solid ${cat.color}55`,
    }}>{cat.label.toUpperCase()}</span>
  );
}

// ── Health advisory ──────────────────────────────────────────────────────────
function healthMsg(aqi) {
  if (!aqi) return null;
  const msgs = [
    [50,  '✅ Air is clean. Great day for outdoor activities.'],
    [100, '😊 Acceptable air. Sensitive groups should take note.'],
    [200, '⚠️ Moderate pollution. Reduce prolonged outdoor exertion.'],
    [300, '🟠 Poor air quality. Sensitive groups should stay indoors.'],
    [400, '🔴 Very poor air. Avoid outdoor activities. Wear N95 mask.'],
    [Infinity, '🚨 Severe pollution! Stay indoors. Keep windows closed.'],
  ];
  return msgs.find(([limit]) => aqi <= limit)?.[1];
}

// ── Live clock ───────────────────────────────────────────────────────────────
function LiveClock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return (
    <span style={{ fontFamily: T.fontMono, fontSize: 12, color: '#8fafc9' }}>
      {now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
    </span>
  );
}

// ── AQI scale legend ─────────────────────────────────────────────────────────
const SCALE = [
  ['Good', '#3aa757', '0–50'],
  ['Satisfactory', '#a3c853', '51–100'],
  ['Moderate', '#f5c518', '101–200'],
  ['Poor', '#f97316', '201–300'],
  ['Very Poor', '#dc2626', '301–400'],
  ['Severe', '#7f1d1d', '401+'],
];

// ════════════════════════════════════════════════════════════════════════════
// Main page
// ════════════════════════════════════════════════════════════════════════════
export default function LiveMap() {
  const [allStations, setAllStations] = useState([]);   // full 434-record dataset
  const [locState, setLocState] = useState('idle');     // idle|loading|done|error
  const [coords, setCoords]   = useState(null);
  const [nearest, setNearest] = useState([]);           // nearest stations to user
  const [selectedIdx, setSelectedIdx] = useState(0);   // which nearby station is shown

  // ── Load static dataset ──────────────────────────────────────────────────
  useEffect(() => {
    fetch('/aqi-data.json')
      .then((r) => r.json())
      .then((data) => {
        const clean = data
          .filter((r) => r.Latitude && r.Longitude && r['PM2.5'])
          .map((r) => ({
            station: r.Station || '',
            state: r.State || '',
            lat: r.Latitude,
            lon: r.Longitude,
            pm25: r['PM2.5'],
            pm10: r['PM10'],
            no2: r['NO2'],
            so2: r['SO2'],
            co: r['CO'],
            ozone: r['Ozone'],
            nh3: r['NH3'],
            rh: r['RH'],
            aqi: pm25ToAQI(r['PM2.5']),
          }));
        setAllStations(clean);
      });
  }, []);

  // ── Geolocation → nearest station lookup (no external API) ───────────────
  const detectLocation = useCallback(() => {
    if (!navigator.geolocation) { setLocState('error'); return; }
    setLocState('loading');
    navigator.geolocation.getCurrentPosition(
      ({ coords: c }) => {
        setCoords({ lat: c.latitude, lng: c.longitude });
        const near = nearestStations(allStations, c.latitude, c.longitude, 5);
        setNearest(near);
        setSelectedIdx(0);
        setLocState('done');
      },
      () => setLocState('error'),
      { timeout: 10000, enableHighAccuracy: true }
    );
  }, [allStations]);

  const shown = nearest[selectedIdx];   // station currently displayed in hero card

  // ── Derive sorted lists ──────────────────────────────────────────────────
  const worst20  = [...allStations].sort((a, b) => b.aqi - a.aqi).slice(0, 20);
  const best5    = [...allStations].sort((a, b) => a.aqi - b.aqi).slice(0, 5);
  const nationalAvg = allStations.length
    ? Math.round(allStations.reduce((s, r) => s + r.aqi, 0) / allStations.length)
    : null;

  return (
    <div style={{ background: T.bg, minHeight: '100vh', fontFamily: T.fontBody }}>

      {/* ── Dark hero band ──────────────────────────────────────────────── */}
      <div style={{
        background: 'linear-gradient(135deg, #0f172a 0%, #1e3a5f 60%, #0f2942 100%)',
        padding: '32px 40px 28px',
        display: 'flex', alignItems: 'center',
        justifyContent: 'space-between', flexWrap: 'wrap', gap: 16,
      }}>
        <div>
          <div style={{ fontFamily: T.fontMono, fontSize: 11, color: '#3aa757', letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: 6, display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#3aa757', display: 'inline-block', boxShadow: '0 0 8px #3aa757' }} />
            LIVE · CPCB Dataset · {allStations.length} Stations
          </div>
          <h1 style={{ fontFamily: T.fontDisplay, fontWeight: 700, fontSize: 28, color: '#f0f4f8', margin: 0 }}>
            India AQI Live Map — 2026
          </h1>
          <p style={{ fontFamily: T.fontBody, fontSize: 14, color: '#8fafc9', margin: '6px 0 0' }}>
            All {allStations.length} CPCB monitoring stations plotted · Detect your location for nearest station AQI
          </p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontFamily: T.fontMono, fontSize: 11, color: '#5b7a96', marginBottom: 2 }}>NATIONAL AVG AQI</div>
            <div style={{ fontFamily: T.fontDisplay, fontWeight: 700, fontSize: 32, color: aqiCategory(nationalAvg).color }}>
              {nationalAvg ?? '--'}
            </div>
          </div>
          <LiveClock />
        </div>
      </div>

      <div style={{ padding: '28px 40px', maxWidth: 1440, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 24 }}>

        {/* ── Your Location card ──────────────────────────────────────── */}
        <Card>
          <div style={{ display: 'flex', gap: 32, flexWrap: 'wrap', alignItems: 'flex-start' }}>

            {/* Left: text + action */}
            <div style={{ flex: 1, minWidth: 280 }}>
              <SLabel>📍 Your Location — Nearest Stations</SLabel>
              <CTitle>Real-Time AQI Near You</CTitle>
              <p style={{ fontFamily: T.fontBody, fontSize: 13, color: T.textSub, marginTop: 6, marginBottom: 20, lineHeight: 1.6 }}>
                Click below to detect your location. We find the <strong>nearest CPCB station</strong> from
                our dataset — no external API, no wrong cities, instant result.
              </p>

              {locState === 'idle' && (
                <button
                  onClick={detectLocation}
                  disabled={allStations.length === 0}
                  style={{
                    fontFamily: T.fontDisplay, fontWeight: 700, fontSize: 15,
                    padding: '12px 28px', borderRadius: 10,
                    background: 'linear-gradient(135deg,#1d4ed8,#3b82f6)',
                    color: '#fff', border: 'none', cursor: 'pointer',
                    boxShadow: '0 4px 16px rgba(29,78,216,0.35)',
                    opacity: allStations.length === 0 ? 0.5 : 1,
                  }}
                >📍 Detect My Location</button>
              )}

              {locState === 'loading' && (
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontFamily: T.fontBody, fontSize: 14, color: T.textSub }}>
                  <div style={{ width: 16, height: 16, border: `2.5px solid ${T.accent}`, borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
                  Detecting your location…
                </div>
              )}

              {locState === 'error' && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  <div style={{ fontFamily: T.fontBody, fontSize: 14, color: '#dc2626' }}>
                    ⚠️ Could not get location. Please allow location access in your browser and try again.
                  </div>
                  <button onClick={detectLocation} style={{ fontFamily: T.fontDisplay, fontWeight: 600, fontSize: 13, padding: '8px 16px', borderRadius: 8, background: T.accentLight, color: T.accent, border: `1px solid rgba(29,78,216,0.3)`, cursor: 'pointer', width: 'fit-content' }}>
                    Try Again
                  </button>
                </div>
              )}

              {locState === 'done' && shown && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                  {/* Health advisory */}
                  <div style={{
                    padding: '12px 16px', borderRadius: 10,
                    background: aqiCategory(shown.aqi).color + '15',
                    border: `1px solid ${aqiCategory(shown.aqi).color}44`,
                    fontFamily: T.fontBody, fontSize: 14, color: T.text, lineHeight: 1.6,
                  }}>
                    {healthMsg(shown.aqi)}
                  </div>

                  {/* Station name + distance */}
                  <div style={{ fontFamily: T.fontBody, fontSize: 13 }}>
                    <span style={{ fontWeight: 600, color: T.text }}>{shown.station.replace(/ - .+$/, '')}</span>
                    <span style={{ color: T.textSub }}> · {shown.state}</span>
                    <span style={{ fontFamily: T.fontMono, fontSize: 11, color: T.accent, marginLeft: 8 }}>
                      {shown.distKm.toFixed(1)} km away
                    </span>
                  </div>

                  {/* Pollutant chips */}
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                    <Chip label="PM2.5" value={shown.pm25} unit="μg/m³" />
                    <Chip label="PM10"  value={shown.pm10}  unit="μg/m³" />
                    <Chip label="NO₂"   value={shown.no2}   unit="μg/m³" />
                    <Chip label="SO₂"   value={shown.so2}   unit="μg/m³" />
                    <Chip label="CO"    value={shown.co}    unit="mg/m³" />
                    <Chip label="O₃"    value={shown.ozone} unit="μg/m³" />
                    <Chip label="NH₃"   value={shown.nh3}   unit="μg/m³" />
                    <Chip label="RH"    value={shown.rh}    unit="%" />
                  </div>

                  {/* Switch between nearby stations */}
                  {nearest.length > 1 && (
                    <div>
                      <div style={{ fontFamily: T.fontMono, fontSize: 11, color: T.textSub, marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.08em' }}>
                        Nearby stations:
                      </div>
                      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                        {nearest.map((s, i) => (
                          <button
                            key={i}
                            onClick={() => setSelectedIdx(i)}
                            style={{
                              fontFamily: T.fontBody, fontSize: 12, fontWeight: i === selectedIdx ? 700 : 400,
                              padding: '5px 12px', borderRadius: 8, cursor: 'pointer',
                              background: i === selectedIdx ? T.accent : T.bg,
                              color: i === selectedIdx ? '#fff' : T.text,
                              border: `1px solid ${i === selectedIdx ? T.accent : T.border}`,
                            }}
                          >
                            {s.station.replace(/ - .+$/, '').substring(0, 20)}
                            <span style={{ fontFamily: T.fontMono, fontSize: 10, opacity: 0.7, marginLeft: 4 }}>
                              {s.distKm.toFixed(1)}km
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 4 }}>
                    <span style={{ fontFamily: T.fontMono, fontSize: 11, color: T.textSub }}>
                      📍 {coords.lat.toFixed(4)}°N, {coords.lng.toFixed(4)}°E
                    </span>
                    <button onClick={detectLocation} style={{ fontFamily: T.fontMono, fontSize: 11, padding: '4px 12px', borderRadius: 6, background: 'transparent', color: T.textSub, border: `1px solid ${T.border}`, cursor: 'pointer' }}>
                      ↻ Refresh
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Right: AQI circle */}
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
              <AQICircle aqi={locState === 'done' ? shown?.aqi : null} size={150} />
              {locState === 'done' && shown && <AQIBadge aqi={shown.aqi} />}
              {locState === 'done' && shown && (
                <div style={{ fontFamily: T.fontDisplay, fontWeight: 600, fontSize: 14, color: T.text, textAlign: 'center', maxWidth: 160 }}>
                  {shown.station.replace(/ - .+$/, '').substring(0, 28)}
                </div>
              )}
              {locState !== 'done' && (
                <div style={{ fontFamily: T.fontBody, fontSize: 13, color: T.textSub, textAlign: 'center' }}>
                  Awaiting location
                </div>
              )}
            </div>
          </div>
        </Card>

        {/* ── AQI Scale ───────────────────────────────────────────────── */}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, alignItems: 'center' }}>
          <span style={{ fontFamily: T.fontMono, fontSize: 11, color: T.textSub, marginRight: 4 }}>SCALE:</span>
          {SCALE.map(([label, color, range]) => (
            <div key={label} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '4px 10px', borderRadius: 99, background: color + '18', border: `1px solid ${color}44` }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: color, display: 'inline-block' }} />
              <span style={{ fontFamily: T.fontMono, fontSize: 11, color: T.text }}>{label}</span>
              <span style={{ fontFamily: T.fontMono, fontSize: 10, color: T.textSub }}>{range}</span>
            </div>
          ))}
          <span style={{ marginLeft: 'auto', fontFamily: T.fontMono, fontSize: 11, color: '#3aa757' }}>
            ● {allStations.length} stations loaded
          </span>
        </div>

        {/* ── India Map ────────────────────────────────────────────────── */}
        <Card style={{ padding: 0, overflow: 'hidden' }}>
          <div style={{ padding: '20px 24px 16px', borderBottom: `1px solid ${T.border}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 10 }}>
            <div>
              <SLabel>🗺️ Interactive Map · 2026</SLabel>
              <CTitle>India AQI Map — All CPCB Stations</CTitle>
            </div>
            <div style={{ fontFamily: T.fontMono, fontSize: 12, color: T.textSub }}>
              Click any circle for station details · Circle size = PM2.5 level
            </div>
          </div>

          <div style={{ height: 580 }}>
            {allStations.length > 0 ? (
              <MapContainer
                center={[22.5, 82]}
                zoom={5}
                style={{ height: '100%', width: '100%' }}
              >
                <TileLayer
                  attribution='© <a href="https://www.openstreetmap.org">OpenStreetMap</a> contributors'
                  url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
                />

                {/* Fly to user location when detected */}
                {coords && <FlyTo lat={coords.lat} lng={coords.lng} zoom={10} />}

                {/* User location marker */}
                {coords && (
                  <CircleMarker
                    center={[coords.lat, coords.lng]}
                    radius={12}
                    pathOptions={{ color: '#1d4ed8', fillColor: '#3b82f6', fillOpacity: 1, weight: 3 }}
                  >
                    <Popup>
                      <strong>📍 Your Location</strong>
                      <br />{coords.lat.toFixed(4)}°N, {coords.lng.toFixed(4)}°E
                      {shown && <><br />Nearest: {shown.station.replace(/ - .+$/, '')} ({shown.distKm.toFixed(1)} km)</>}
                    </Popup>
                  </CircleMarker>
                )}

                {/* All 430+ CPCB station markers */}
                {allStations.map((s, i) => {
                  const cat = aqiCategory(s.aqi);
                  const r = Math.min(24, Math.max(5, s.aqi / 16));
                  const isNearest = nearest[0]?.station === s.station && locState === 'done';
                  return (
                    <CircleMarker
                      key={i}
                      center={[s.lat, s.lon]}
                      radius={isNearest ? r + 5 : r}
                      pathOptions={{
                        color: isNearest ? '#1d4ed8' : cat.color,
                        fillColor: cat.color,
                        fillOpacity: 0.75,
                        weight: isNearest ? 3 : 1.5,
                      }}
                    >
                      <Popup>
                        <div style={{ fontFamily: T.fontBody, minWidth: 180 }}>
                          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 4 }}>
                            {s.station.replace(/ - .+$/, '')}
                          </div>
                          <div style={{ fontSize: 12, color: '#5b6b7c', marginBottom: 8 }}>{s.state}</div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                            <span style={{ fontWeight: 700, fontSize: 26, color: cat.color }}>{s.aqi}</span>
                            <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 99, background: cat.color + '22', color: cat.color, border: `1px solid ${cat.color}44` }}>
                              {cat.label}
                            </span>
                          </div>
                          <div style={{ fontSize: 12, color: '#3c4a59' }}>
                            PM2.5: <strong>{s.pm25}</strong> μg/m³ &nbsp;|&nbsp;
                            PM10: <strong>{Math.round(s.pm10 ?? 0)}</strong> μg/m³
                          </div>
                          {s.no2 && <div style={{ fontSize: 12, color: '#3c4a59', marginTop: 2 }}>NO₂: <strong>{s.no2.toFixed(1)}</strong> &nbsp;SO₂: <strong>{(s.so2 ?? 0).toFixed(1)}</strong></div>}
                          {isNearest && <div style={{ marginTop: 6, fontSize: 11, color: '#1d4ed8', fontWeight: 600 }}>📍 Nearest to you ({nearest[0].distKm.toFixed(1)} km)</div>}
                        </div>
                      </Popup>
                    </CircleMarker>
                  );
                })}
              </MapContainer>
            ) : (
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', fontFamily: T.fontBody, color: T.textSub }}>
                Loading station data…
              </div>
            )}
          </div>
        </Card>

        {/* ── Worst + Best stations side by side ──────────────────────── */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
          {/* Worst 20 */}
          <Card>
            <SLabel>🔴 Most Polluted Right Now</SLabel>
            <CTitle>Top 20 Worst Stations</CTitle>
            <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 0 }}>
              {worst20.map((s, i) => {
                const cat = aqiCategory(s.aqi);
                return (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '9px 0', borderBottom: `1px solid ${T.border}` }}>
                    <span style={{ fontFamily: T.fontMono, fontSize: 11, color: T.textSub, width: 20, flexShrink: 0 }}>{i + 1}</span>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontFamily: T.fontBody, fontSize: 13, fontWeight: 600, color: T.text, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {s.station.replace(/ - .+$/, '')}
                      </div>
                      <div style={{ fontFamily: T.fontMono, fontSize: 11, color: T.textSub }}>{s.state}</div>
                    </div>
                    <span style={{ fontFamily: T.fontDisplay, fontWeight: 700, fontSize: 18, color: cat.color, flexShrink: 0 }}>{s.aqi}</span>
                    <span style={{ fontFamily: T.fontMono, fontSize: 10, padding: '2px 7px', borderRadius: 99, background: cat.color + '22', color: cat.color, border: `1px solid ${cat.color}44`, flexShrink: 0 }}>
                      {cat.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </Card>

          {/* Cleanest 5 + state summary */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
            <Card>
              <SLabel>🟢 Cleanest Stations</SLabel>
              <CTitle>Best Air Quality</CTitle>
              <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 0 }}>
                {best5.map((s, i) => {
                  const cat = aqiCategory(s.aqi);
                  return (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '9px 0', borderBottom: `1px solid ${T.border}` }}>
                      <span style={{ fontFamily: T.fontMono, fontSize: 11, color: T.textSub, width: 20, flexShrink: 0 }}>{i + 1}</span>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontFamily: T.fontBody, fontSize: 13, fontWeight: 600, color: T.text, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {s.station.replace(/ - .+$/, '')}
                        </div>
                        <div style={{ fontFamily: T.fontMono, fontSize: 11, color: T.textSub }}>{s.state}</div>
                      </div>
                      <span style={{ fontFamily: T.fontDisplay, fontWeight: 700, fontSize: 18, color: cat.color }}>{s.aqi}</span>
                      <span style={{ fontFamily: T.fontMono, fontSize: 10, padding: '2px 7px', borderRadius: 99, background: cat.color + '22', color: cat.color, border: `1px solid ${cat.color}44` }}>
                        {cat.label}
                      </span>
                    </div>
                  );
                })}
              </div>
            </Card>

            {/* Quick stats */}
            <Card>
              <SLabel>National Snapshot</SLabel>
              <CTitle>India Air Quality Summary</CTitle>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 16 }}>
                {[
                  ['Total Stations', allStations.length],
                  ['Good (0–50)', allStations.filter(s => s.aqi <= 50).length],
                  ['Satisfactory (51–100)', allStations.filter(s => s.aqi > 50 && s.aqi <= 100).length],
                  ['Moderate (101–200)', allStations.filter(s => s.aqi > 100 && s.aqi <= 200).length],
                  ['Poor (201–300)', allStations.filter(s => s.aqi > 200 && s.aqi <= 300).length],
                  ['Very Poor / Severe (>300)', allStations.filter(s => s.aqi > 300).length],
                ].map(([label, count]) => {
                  const pct = allStations.length ? Math.round((Number(count) / allStations.length) * 100) : 0;
                  const color = label.includes('Good') ? '#3aa757' : label.includes('Satisfactory') ? '#a3c853' : label.includes('Moderate') ? '#f5c518' : label.includes('Poor (') ? '#f97316' : label.includes('Very') ? '#dc2626' : T.accent;
                  return (
                    <div key={label}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                        <span style={{ fontFamily: T.fontBody, fontSize: 13, color: T.text }}>{label}</span>
                        <span style={{ fontFamily: T.fontMono, fontSize: 12, fontWeight: 600, color }}>{count}</span>
                      </div>
                      {label !== 'Total Stations' && (
                        <div style={{ height: 5, borderRadius: 3, background: T.border, overflow: 'hidden' }}>
                          <div style={{ height: '100%', width: `${pct}%`, background: color, borderRadius: 3, transition: 'width 0.6s' }} />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </Card>
          </div>
        </div>

        <div style={{ fontFamily: T.fontMono, fontSize: 11, color: T.textSub, textAlign: 'center', paddingBottom: 16 }}>
          Data source: CPCB · INSAT-3DR · MERRA-NASA · CPCB AQI Standard (PM2.5 sub-index)
        </div>
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
