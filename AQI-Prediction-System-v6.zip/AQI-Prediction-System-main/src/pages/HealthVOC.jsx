import { useState, useEffect, useRef, useCallback } from 'react';
import { Bar, Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement,
  ArcElement, Tooltip, Legend,
} from 'chart.js';
import { pm25ToAQI, aqiCategory } from '../utils/aqiData';

ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Tooltip, Legend);

// ── Design tokens ────────────────────────────────────────────────────────────
const T = {
  bg: '#f0f4f8', surface: '#fff',
  border: 'rgba(148,163,184,0.28)', text: '#16202c', textSub: '#5b6b7c',
  accent: '#1d4ed8', accentLight: 'rgba(29,78,216,0.08)',
  danger: '#dc2626', dangerLight: 'rgba(220,38,38,0.08)',
  warn: '#f97316', warnLight: 'rgba(249,115,22,0.08)',
  good: '#3aa757', goodLight: 'rgba(58,167,87,0.08)',
  fontDisplay: "'Space Grotesk', sans-serif",
  fontBody: "'Inter', sans-serif",
  fontMono: "'IBM Plex Mono', monospace",
  radius: '12px',
  shadow: '0 1px 4px rgba(0,0,0,0.07), 0 4px 16px rgba(0,0,0,0.05)',
};

// ── State populations (2024 estimates, millions) ─────────────────────────────
const STATE_POP = {
  'Delhi': 33, 'Uttar Pradesh': 241, 'Maharashtra': 126, 'Bihar': 130,
  'West_Bengal': 100, 'Rajasthan': 83, 'Madhya Pradesh': 87, 'Tamil Nadu': 79,
  'Karnataka': 69, 'Gujarat': 68, 'Andhra Pradesh': 54, 'Odisha': 48,
  'Telangana': 40, 'Kerala': 36, 'Haryana': 30, 'Punjab': 31,
  'Chhattisgarh': 31, 'Jharkhand': 40, 'Assam': 36, 'Uttarakhand': 12,
  'Himachal Pradesh': 7, 'Chandigarh': 1.2, 'Jammu & Kashmir': 14,
  'Goa': 1.6, 'Tripura': 4, 'Meghalaya': 3.4, 'Nagaland': 2.3,
  'Manipur': 3.3, 'Arunachal Pradesh': 1.7, 'Sikkim': 0.7,
};

// ── WHO / Indian limits ──────────────────────────────────────────────────────
const VOC_LIMITS = {
  'Benzene':     { who: 1.7,  india: 5,   unit: 'μg/m³', carcinogen: true,  label: 'Benzene (C₆H₆)' },
  'Toluene':     { who: 260,  india: 400, unit: 'μg/m³', carcinogen: false, label: 'Toluene' },
  'Eth-Benzene': { who: 22,   india: 50,  unit: 'μg/m³', carcinogen: true,  label: 'Ethyl-Benzene' },
  'MP-Xylene':   { who: 100,  india: 150, unit: 'μg/m³', carcinogen: false, label: 'MP-Xylene' },
  'O-Xylene':    { who: 100,  india: 150, unit: 'μg/m³', carcinogen: false, label: 'O-Xylene' },
};

// ── WHO PM2.5 concentration-response function ────────────────────────────────
// Source: WHO Global Air Quality Guidelines 2021
// Excess deaths = Pop × BaselineMortality × (1 - exp(-β × max(0, PM2.5 - 2.5)))
// β = 0.00116 (all-cause mortality, Burnett et al. 2018 integrated exposure-response)
const BASELINE_MORTALITY_RATE = 0.0073; // India crude death rate per person per year
const BETA = 0.00116;
const COUNTERFACTUAL_PM25 = 2.5; // WHO theoretical minimum risk concentration

function calcHealthImpact(pm25, stateName) {
  const pop = (STATE_POP[stateName] || 10) * 1_000_000;
  const excess = pm25 > COUNTERFACTUAL_PM25
    ? pop * BASELINE_MORTALITY_RATE * (1 - Math.exp(-BETA * (pm25 - COUNTERFACTUAL_PM25)))
    : 0;
  return {
    excessDeaths: Math.round(excess),
    hospitalAdmissions: Math.round(excess * 4.2),   // ~4x deaths → admissions (WHO ratio)
    yllPerYear: Math.round(excess * 11.7),           // avg 11.7 years lost per premature death
    population: pop,
    pm25Safe: COUNTERFACTUAL_PM25,
    reduction: Math.max(0, pm25 - COUNTERFACTUAL_PM25).toFixed(1),
    riskIncrease: Math.round((1 - Math.exp(-BETA * Math.max(0, pm25 - COUNTERFACTUAL_PM25))) * 100),
  };
};

// ── UI helpers ───────────────────────────────────────────────────────────────
function Card({ children, style = {} }) {
  return <div style={{ background: T.surface, borderRadius: T.radius, border: `1px solid ${T.border}`, boxShadow: T.shadow, padding: '24px', ...style }}>{children}</div>;
}
function SLabel({ children, color }) {
  return <div style={{ fontFamily: T.fontMono, fontSize: 11, fontWeight: 600, letterSpacing: '0.12em', color: color || T.textSub, textTransform: 'uppercase', marginBottom: 10 }}>{children}</div>;
}
function CTitle({ children }) {
  return <h2 style={{ fontFamily: T.fontDisplay, fontWeight: 700, fontSize: 18, color: T.text, margin: '0 0 4px 0' }}>{children}</h2>;
}
function StatBox({ label, value, sub, color, big }) {
  return (
    <div style={{ background: color ? color + '10' : T.bg, border: `1px solid ${color ? color + '33' : T.border}`, borderRadius: 10, padding: '16px 20px', flex: 1, minWidth: 140 }}>
      <div style={{ fontFamily: T.fontMono, fontSize: 10, color: T.textSub, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6 }}>{label}</div>
      <div style={{ fontFamily: T.fontDisplay, fontWeight: 700, fontSize: big ? 32 : 24, color: color || T.text, lineHeight: 1 }}>{value}</div>
      {sub && <div style={{ fontFamily: T.fontBody, fontSize: 12, color: T.textSub, marginTop: 4 }}>{sub}</div>}
    </div>
  );
}

// ── Toast notification system ─────────────────────────────────────────────────
function ToastContainer({ toasts, onDismiss }) {
  return (
    <div style={{ position: 'fixed', top: 72, right: 24, zIndex: 9999, display: 'flex', flexDirection: 'column', gap: 10, maxWidth: 380 }}>
      {toasts.map((t) => (
        <div key={t.id} style={{
          background: t.type === 'danger' ? '#1a0505' : t.type === 'warn' ? '#1a0e05' : '#051a0e',
          border: `1px solid ${t.type === 'danger' ? T.danger : t.type === 'warn' ? T.warn : T.good}55`,
          borderLeft: `4px solid ${t.type === 'danger' ? T.danger : t.type === 'warn' ? T.warn : T.good}`,
          borderRadius: 10, padding: '14px 16px',
          boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
          display: 'flex', alignItems: 'flex-start', gap: 12,
          animation: 'slideIn 0.3s ease',
        }}>
          <span style={{ fontSize: 18, flexShrink: 0 }}>{t.icon}</span>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: T.fontDisplay, fontWeight: 700, fontSize: 13, color: '#f0f4f8', marginBottom: 3 }}>{t.title}</div>
            <div style={{ fontFamily: T.fontBody, fontSize: 12, color: '#8fafc9', lineHeight: 1.5 }}>{t.message}</div>
          </div>
          <button onClick={() => onDismiss(t.id)} style={{ background: 'none', border: 'none', color: '#5b7a96', cursor: 'pointer', fontSize: 16, flexShrink: 0, padding: 0 }}>×</button>
        </div>
      ))}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// Main Page
// ═══════════════════════════════════════════════════════════════════════════════
export default function HealthVOC() {
  const [data, setData] = useState([]);
  const [states, setStates] = useState([]);           // aggregated by state
  const [selectedState, setSelectedState] = useState('Delhi');
  const [activeTab, setActiveTab] = useState('health'); // health | voc
  const [toasts, setToasts] = useState([]);
  const [notifPermission, setNotifPermission] = useState('default');
  const [vocFilter, setVocFilter] = useState('Benzene');
  const [showOnlyExceeded, setShowOnlyExceeded] = useState(false);
  const toastIdRef = useRef(0);

  // ── Load data ──────────────────────────────────────────────────────────────
  useEffect(() => {
    fetch('/aqi-data.json')
      .then(r => r.json())
      .then(raw => {
        setData(raw);

        // Aggregate by state
        const byState = {};
        for (const r of raw) {
          const s = r.State;
          if (!byState[s]) byState[s] = { state: s, pm25vals: [], voc: { Benzene: [], Toluene: [], 'Eth-Benzene': [], 'MP-Xylene': [], 'O-Xylene': [] }, stations: [] };
          if (r['PM2.5']) byState[s].pm25vals.push(r['PM2.5']);
          for (const f of Object.keys(VOC_LIMITS)) if (r[f]) byState[s].voc[f].push(r[f]);
          byState[s].stations.push(r);
        }
        const agg = Object.values(byState).map(s => ({
          state: s.state,
          avgPm25: s.pm25vals.length ? s.pm25vals.reduce((a, v) => a + v, 0) / s.pm25vals.length : 0,
          aqi: pm25ToAQI(s.pm25vals.length ? s.pm25vals.reduce((a, v) => a + v, 0) / s.pm25vals.length : 0),
          voc: Object.fromEntries(Object.entries(s.voc).map(([k, arr]) => [k, arr.length ? arr.reduce((a, v) => a + v, 0) / arr.length : null])),
          stationCount: s.stations.length,
          stations: s.stations,
        })).sort((a, b) => b.avgPm25 - a.avgPm25);

        setStates(agg);

        // ── Fire AQI alert toasts on load ──────────────────────────────────
        const criticalStates = agg.filter(s => s.aqi > 300);
        const severeStates = agg.filter(s => s.aqi > 200 && s.aqi <= 300);
        const benzeneViolators = agg.filter(s => s.voc.Benzene && s.voc.Benzene > 1.7);

        setTimeout(() => {
          if (criticalStates.length > 0) {
            pushToast('danger', '🚨 Critical AQI Alert',
              `${criticalStates.map(s => s.state).join(', ')} have AQI > 300 (Severe). Immediate health risk.`);
          }
          if (severeStates.length > 0) {
            setTimeout(() => pushToast('warn', '⚠️ Poor Air Quality Warning',
              `${severeStates.length} state(s) including ${severeStates[0].state} have AQI between 200–300. Vulnerable groups at risk.`), 800);
          }
          if (benzeneViolators.length > 0) {
            setTimeout(() => pushToast('danger', '☣️ Carcinogen Limit Exceeded',
              `${benzeneViolators.length} state(s) exceed WHO Benzene safe limit (1.7 μg/m³) — a Class 1 carcinogen.`), 1600);
          }
        }, 600);
      });

    // Check browser notification permission
    if ('Notification' in window) setNotifPermission(Notification.permission);
  }, []);

  // ── Toast helpers ──────────────────────────────────────────────────────────
  const pushToast = useCallback((type, title, message, icon) => {
    const icons = { danger: '🔴', warn: '🟠', good: '🟢' };
    const id = ++toastIdRef.current;
    setToasts(prev => [...prev.slice(-4), { id, type, title, message, icon: icon || icons[type] }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 7000);

    // Also fire browser notification if permitted
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(`AQ-INDIA: ${title}`, { body: message, icon: '/favicon.ico' });
    }
  }, []);

  const dismissToast = useCallback((id) => setToasts(prev => prev.filter(t => t.id !== id)), []);

  const requestNotifPermission = async () => {
    if ('Notification' in window) {
      const perm = await Notification.requestPermission();
      setNotifPermission(perm);
      if (perm === 'granted') pushToast('good', '🔔 Notifications Enabled', 'You will now receive AQI alerts even when the tab is in the background.');
    }
  };

  // ── Derived data ───────────────────────────────────────────────────────────
  const stateData = states.find(s => s.state === selectedState) || states[0];
  const health = stateData ? calcHealthImpact(stateData.avgPm25, selectedState) : null;

  // VOC table: all stations with VOC data
  const vocRows = data
    .filter(r => r[vocFilter] != null)
    .map(r => ({
      station: r.Station || '', state: r.State || '',
      value: r[vocFilter], limit: VOC_LIMITS[vocFilter],
      exceeded: r[vocFilter] > VOC_LIMITS[vocFilter].who,
      ratio: r[vocFilter] / VOC_LIMITS[vocFilter].who,
      allVOC: Object.fromEntries(Object.keys(VOC_LIMITS).map(f => [f, r[f]])),
    }))
    .filter(r => !showOnlyExceeded || r.exceeded)
    .sort((a, b) => b.value - a.value);

  const exceededCount = data.filter(r => r[vocFilter] != null && r[vocFilter] > VOC_LIMITS[vocFilter].who).length;
  const totalVOC = data.filter(r => r[vocFilter] != null).length;

  // Bar chart: top 12 benzene states
  const vocStateData = states
    .filter(s => s.voc[vocFilter] != null)
    .sort((a, b) => (b.voc[vocFilter] || 0) - (a.voc[vocFilter] || 0))
    .slice(0, 12);

  const barData = {
    labels: vocStateData.map(s => s.state),
    datasets: [{
      label: `Avg ${vocFilter} (μg/m³)`,
      data: vocStateData.map(s => s.voc[vocFilter]?.toFixed(2)),
      backgroundColor: vocStateData.map(s =>
        (s.voc[vocFilter] || 0) > VOC_LIMITS[vocFilter].who ? T.danger + 'cc' : T.accent + 'cc'
      ),
      borderColor: vocStateData.map(s =>
        (s.voc[vocFilter] || 0) > VOC_LIMITS[vocFilter].who ? T.danger : T.accent
      ),
      borderWidth: 1.5, borderRadius: 4,
    }],
  };

  const barOpts = {
    responsive: true, maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#16202c',
        titleFont: { family: T.fontDisplay },
        bodyFont: { family: T.fontMono },
        callbacks: {
          afterLabel: (ctx) => {
            const limit = VOC_LIMITS[vocFilter].who;
            const ratio = (ctx.raw / limit).toFixed(1);
            return `${ratio}× WHO limit (${limit} μg/m³)`;
          }
        }
      },
    },
    scales: {
      x: { grid: { display: false }, ticks: { font: { family: T.fontMono, size: 11 }, color: T.textSub } },
      y: {
        grid: { color: 'rgba(148,163,184,0.15)' },
        ticks: { font: { family: T.fontMono, size: 11 }, color: T.textSub },
        title: { display: true, text: `${vocFilter} (μg/m³)`, font: { family: T.fontBody, size: 12 }, color: T.textSub },
      },
    },
  };

  // Doughnut: exceed vs safe
  const doughnutData = {
    labels: ['Exceeds WHO limit', 'Within safe limit'],
    datasets: [{ data: [exceededCount, totalVOC - exceededCount], backgroundColor: [T.danger + 'cc', T.good + 'cc'], borderColor: [T.danger, T.good], borderWidth: 2 }],
  };

  return (
    <div style={{ background: T.bg, minHeight: '100vh', fontFamily: T.fontBody }}>
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />

      {/* ── Hero ──────────────────────────────────────────────────────────── */}
      <div style={{
        background: 'linear-gradient(135deg, #1a0505 0%, #3b0a0a 40%, #1a0f00 100%)',
        padding: '32px 40px 28px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 20,
      }}>
        <div>
          <div style={{ fontFamily: T.fontMono, fontSize: 11, color: '#f87171', letterSpacing: '0.14em', textTransform: 'uppercase', marginBottom: 6, display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#f87171', display: 'inline-block', boxShadow: '0 0 8px #f87171' }} />
            Health Risk · Carcinogen Analysis
          </div>
          <h1 style={{ fontFamily: T.fontDisplay, fontWeight: 700, fontSize: 28, color: '#f0f4f8', margin: 0 }}>
            Health Impact & VOC Analyser
          </h1>
          <p style={{ fontFamily: T.fontBody, fontSize: 14, color: '#c9a0a0', margin: '6px 0 0', maxWidth: 600 }}>
            WHO PM2.5 concentration-response model · Benzene (Class 1 carcinogen) exceedance analysis · 
            Real-time AQI alerts for {states.length} Indian states
          </p>
        </div>

        {/* Notification permission button */}
        <button
          onClick={notifPermission !== 'granted' ? requestNotifPermission : undefined}
          style={{
            fontFamily: T.fontDisplay, fontWeight: 600, fontSize: 13,
            padding: '10px 20px', borderRadius: 10,
            background: notifPermission === 'granted' ? 'rgba(58,167,87,0.2)' : 'rgba(220,38,38,0.2)',
            color: notifPermission === 'granted' ? '#4ade80' : '#fca5a5',
            border: `1px solid ${notifPermission === 'granted' ? '#3aa75755' : '#dc262655'}`,
            cursor: notifPermission === 'granted' ? 'default' : 'pointer',
            display: 'flex', alignItems: 'center', gap: 8,
          }}
        >
          {notifPermission === 'granted' ? '🔔 AQI Alerts Active' : '🔕 Enable AQI Alerts'}
        </button>
      </div>

      {/* ── Tab nav ───────────────────────────────────────────────────────── */}
      <div style={{ background: T.surface, borderBottom: `1px solid ${T.border}`, padding: '0 40px', display: 'flex', gap: 0 }}>
        {[
          { id: 'health', label: '💔 Health Impact Estimator' },
          { id: 'voc', label: '☣️ VOC / Toxic Gas Analyser' },
        ].map(({ id, label }) => (
          <button key={id} onClick={() => setActiveTab(id)} style={{
            fontFamily: T.fontDisplay, fontWeight: 600, fontSize: 14, padding: '16px 24px',
            border: 'none', borderBottom: activeTab === id ? `2.5px solid ${T.danger}` : '2.5px solid transparent',
            background: 'transparent', color: activeTab === id ? T.danger : T.textSub, cursor: 'pointer',
          }}>{label}</button>
        ))}
      </div>

      <div style={{ padding: '32px 40px', maxWidth: 1440, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 24 }}>

        {/* ════════════════════════════════════════════════════════════════
            TAB 1: HEALTH IMPACT ESTIMATOR
        ════════════════════════════════════════════════════════════════ */}
        {activeTab === 'health' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>

            {/* Methodology note */}
            <div style={{
              background: 'rgba(29,78,216,0.06)', border: `1px solid rgba(29,78,216,0.2)`,
              borderRadius: T.radius, padding: '14px 20px',
              fontFamily: T.fontBody, fontSize: 13, color: T.textSub, lineHeight: 1.7,
            }}>
              <strong style={{ color: T.text }}>Methodology:</strong> Uses the WHO Global Air Quality Guidelines 2021 integrated exposure-response (IER) function 
              (Burnett et al. 2018). Formula: <span style={{ fontFamily: T.fontMono, fontSize: 12 }}>Excess Deaths = Population × BaselineMortality × (1 − e<sup>−β(PM2.5 − 2.5)</sup>)</span>, 
              where β = 0.00116 and counterfactual concentration = 2.5 μg/m³. Hospital admissions estimated at 4.2× excess deaths (WHO burden of disease ratio).
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr', gap: 24 }}>

              {/* State selector */}
              <Card>
                <SLabel>Select State</SLabel>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 3, maxHeight: 520, overflowY: 'auto' }}>
                  {states.map(s => {
                    const cat = aqiCategory(s.aqi);
                    const h = calcHealthImpact(s.avgPm25, s.state);
                    return (
                      <button key={s.state} onClick={() => setSelectedState(s.state)} style={{
                        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                        padding: '9px 12px', borderRadius: 8, border: selectedState === s.state ? `1.5px solid ${T.danger}` : '1px solid transparent',
                        background: selectedState === s.state ? T.dangerLight : 'transparent',
                        cursor: 'pointer',
                      }}>
                        <div style={{ textAlign: 'left' }}>
                          <div style={{ fontFamily: T.fontBody, fontSize: 13, fontWeight: 600, color: T.text }}>{s.state}</div>
                          <div style={{ fontFamily: T.fontMono, fontSize: 10, color: T.textSub }}>~{h.excessDeaths.toLocaleString()} est. deaths/yr</div>
                        </div>
                        <span style={{ fontFamily: T.fontDisplay, fontWeight: 700, fontSize: 14, color: cat.color }}>{s.aqi}</span>
                      </button>
                    );
                  })}
                </div>
              </Card>

              {/* Right panel */}
              {health && stateData && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>

                  {/* KPI cards */}
                  <Card style={{ padding: '20px 24px' }}>
                    <SLabel color={T.danger}>⚠️ Estimated Annual Health Burden · {selectedState}</SLabel>
                    <CTitle>Population: {(health.population / 1_000_000).toFixed(1)}M · Avg PM2.5: {stateData.avgPm25.toFixed(1)} μg/m³</CTitle>
                    <p style={{ fontFamily: T.fontBody, fontSize: 13, color: T.textSub, margin: '6px 0 20px', lineHeight: 1.6 }}>
                      If PM2.5 were reduced to WHO safe level (2.5 μg/m³), current levels are <strong style={{ color: T.danger }}>{health.reduction} μg/m³ above safe</strong>, 
                      representing a <strong style={{ color: T.danger }}>{health.riskIncrease}% elevated all-cause mortality risk</strong>.
                    </p>
                    <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
                      <StatBox label="Est. Excess Deaths / Year" value={health.excessDeaths.toLocaleString()} sub="attributable to PM2.5 exposure" color={T.danger} big />
                      <StatBox label="Hospital Admissions / Year" value={health.hospitalAdmissions.toLocaleString()} sub="respiratory & cardiovascular" color={T.warn} big />
                      <StatBox label="Years of Life Lost / Year" value={health.yllPerYear.toLocaleString()} sub="11.7 avg years per premature death" color="#7c3aed" big />
                    </div>
                  </Card>

                  {/* Visual risk meter */}
                  <Card>
                    <SLabel>Mortality Risk Increase vs WHO Safe Level</SLabel>
                    <CTitle>PM2.5 Reduction Needed: {health.reduction} μg/m³</CTitle>
                    <div style={{ marginTop: 20 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                        <span style={{ fontFamily: T.fontBody, fontSize: 13, color: T.textSub }}>WHO safe (2.5 μg/m³)</span>
                        <span style={{ fontFamily: T.fontBody, fontSize: 13, color: T.textSub }}>Current ({stateData.avgPm25.toFixed(1)} μg/m³)</span>
                      </div>
                      <div style={{ height: 24, borderRadius: 12, background: T.bg, overflow: 'hidden', border: `1px solid ${T.border}`, position: 'relative' }}>
                        <div style={{
                          height: '100%',
                          width: `${Math.min(100, (stateData.avgPm25 / 250) * 100)}%`,
                          background: `linear-gradient(90deg, ${T.good}, ${T.warn}, ${T.danger})`,
                          borderRadius: 12, transition: 'width 0.8s ease',
                          display: 'flex', alignItems: 'center', justifyContent: 'flex-end', paddingRight: 10,
                        }}>
                          <span style={{ fontFamily: T.fontMono, fontSize: 11, color: '#fff', fontWeight: 700 }}>{health.riskIncrease}%↑</span>
                        </div>
                      </div>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginTop: 20 }}>
                      {[
                        ['Current Avg PM2.5', `${stateData.avgPm25.toFixed(1)} μg/m³`, T.danger],
                        ['WHO Guideline 2021', '5.0 μg/m³', T.good],
                        ['India NAAQS Standard', '40 μg/m³', T.warn],
                        ['Exceeds WHO by', `${Math.max(0, stateData.avgPm25 - 5).toFixed(1)} μg/m³`, T.danger],
                        ['Exceeds India NAAQS', stateData.avgPm25 > 40 ? `${(stateData.avgPm25 - 40).toFixed(1)} μg/m³ above` : 'Within limit', stateData.avgPm25 > 40 ? T.danger : T.good],
                        ['Monitoring Stations', stateData.stationCount, T.accent],
                      ].map(([label, val, color]) => (
                        <div key={label} style={{ background: T.bg, borderRadius: 8, padding: '12px 14px', border: `1px solid ${T.border}` }}>
                          <div style={{ fontFamily: T.fontMono, fontSize: 10, color: T.textSub, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>{label}</div>
                          <div style={{ fontFamily: T.fontDisplay, fontWeight: 700, fontSize: 16, color }}>{val}</div>
                        </div>
                      ))}
                    </div>
                  </Card>

                  {/* All-state ranked health impact table */}
                  <Card>
                    <SLabel color={T.danger}>All States — Ranked by Health Burden</SLabel>
                    <CTitle>Estimated Annual Excess Deaths by State</CTitle>
                    <div style={{ overflowX: 'auto', marginTop: 16 }}>
                      <table style={{ width: '100%', borderCollapse: 'collapse', fontFamily: T.fontBody, fontSize: 13 }}>
                        <thead>
                          <tr style={{ borderBottom: `2px solid ${T.border}` }}>
                            {['Rank', 'State', 'Avg PM2.5', 'AQI', 'Population', 'Est. Excess Deaths', 'Hospital Admissions', 'YLL'].map(h => (
                              <th key={h} style={{ padding: '8px 12px', textAlign: 'left', fontFamily: T.fontMono, fontSize: 10, color: T.textSub, letterSpacing: '0.06em', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {states.map((s, i) => {
                            const h = calcHealthImpact(s.avgPm25, s.state);
                            const cat = aqiCategory(s.aqi);
                            const isSelected = s.state === selectedState;
                            return (
                              <tr key={s.state}
                                onClick={() => setSelectedState(s.state)}
                                style={{ borderBottom: `1px solid ${T.border}`, cursor: 'pointer', background: isSelected ? T.dangerLight : 'transparent', transition: 'background 0.12s' }}
                                onMouseEnter={e => e.currentTarget.style.background = T.dangerLight}
                                onMouseLeave={e => e.currentTarget.style.background = isSelected ? T.dangerLight : 'transparent'}
                              >
                                <td style={{ padding: '10px 12px', fontFamily: T.fontMono, color: T.textSub }}>{i + 1}</td>
                                <td style={{ padding: '10px 12px', fontWeight: 600 }}>{s.state}</td>
                                <td style={{ padding: '10px 12px', fontFamily: T.fontMono }}>{s.avgPm25.toFixed(1)}</td>
                                <td style={{ padding: '10px 12px', fontFamily: T.fontDisplay, fontWeight: 700, color: cat.color }}>{s.aqi}</td>
                                <td style={{ padding: '10px 12px', fontFamily: T.fontMono }}>{((STATE_POP[s.state] || 10)).toFixed(0)}M</td>
                                <td style={{ padding: '10px 12px', fontFamily: T.fontDisplay, fontWeight: 700, color: h.excessDeaths > 10000 ? T.danger : h.excessDeaths > 1000 ? T.warn : T.text }}>{h.excessDeaths.toLocaleString()}</td>
                                <td style={{ padding: '10px 12px', fontFamily: T.fontMono }}>{h.hospitalAdmissions.toLocaleString()}</td>
                                <td style={{ padding: '10px 12px', fontFamily: T.fontMono }}>{h.yllPerYear.toLocaleString()}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </Card>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ════════════════════════════════════════════════════════════════
            TAB 2: VOC ANALYSER
        ════════════════════════════════════════════════════════════════ */}
        {activeTab === 'voc' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>

            {/* Alert banner */}
            <div style={{ background: T.dangerLight, border: `1px solid ${T.danger}44`, borderRadius: T.radius, padding: '16px 20px', display: 'flex', alignItems: 'flex-start', gap: 16 }}>
              <span style={{ fontSize: 24 }}>☣️</span>
              <div>
                <div style={{ fontFamily: T.fontDisplay, fontWeight: 700, fontSize: 15, color: T.danger, marginBottom: 4 }}>Benzene is a WHO Class 1 Carcinogen</div>
                <div style={{ fontFamily: T.fontBody, fontSize: 13, color: T.textSub, lineHeight: 1.7 }}>
                  The WHO annual guideline for Benzene is <strong>1.7 μg/m³</strong>. There is no safe level of exposure — any concentration increases leukemia risk.
                  Of {totalVOC} stations with Benzene measurements, <strong style={{ color: T.danger }}>{exceededCount} ({Math.round(exceededCount / totalVOC * 100)}%) exceed the WHO limit</strong>.
                  Ethyl-Benzene is also a possible carcinogen (IARC Group 2B).
                </div>
              </div>
            </div>

            {/* VOC filter selector */}
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
              <span style={{ fontFamily: T.fontMono, fontSize: 11, color: T.textSub, marginRight: 4 }}>COMPOUND:</span>
              {Object.entries(VOC_LIMITS).map(([key, lim]) => (
                <button key={key} onClick={() => setVocFilter(key)} style={{
                  fontFamily: T.fontDisplay, fontSize: 13, fontWeight: vocFilter === key ? 700 : 500,
                  padding: '6px 14px', borderRadius: 8, cursor: 'pointer',
                  background: vocFilter === key ? T.danger : T.bg,
                  color: vocFilter === key ? '#fff' : T.text,
                  border: `1px solid ${vocFilter === key ? T.danger : T.border}`,
                  display: 'flex', alignItems: 'center', gap: 6,
                }}>
                  {lim.carcinogen && <span style={{ fontSize: 10, background: '#7f1d1d', color: '#fca5a5', padding: '1px 5px', borderRadius: 3 }}>CANCER</span>}
                  {lim.label}
                </button>
              ))}
              <label style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 8, fontFamily: T.fontBody, fontSize: 13, color: T.textSub, cursor: 'pointer' }}>
                <input type="checkbox" checked={showOnlyExceeded} onChange={e => setShowOnlyExceeded(e.target.checked)} />
                Show only exceeded stations
              </label>
            </div>

            {/* Charts row */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 280px', gap: 24 }}>
              <Card>
                <SLabel color={T.danger}>State Comparison — {VOC_LIMITS[vocFilter].label}</SLabel>
                <CTitle>Avg Concentration by State vs WHO Limit ({VOC_LIMITS[vocFilter].who} μg/m³)</CTitle>
                <div style={{ height: 320, marginTop: 16 }}>
                  <Bar data={barData} options={barOpts} />
                </div>
                {/* WHO limit line annotation in legend */}
                <div style={{ display: 'flex', gap: 16, marginTop: 12, fontFamily: T.fontMono, fontSize: 11 }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><span style={{ width: 12, height: 12, borderRadius: 2, background: T.danger + 'cc', display: 'inline-block' }} />Exceeds WHO limit</span>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}><span style={{ width: 12, height: 12, borderRadius: 2, background: T.accent + 'cc', display: 'inline-block' }} />Within WHO limit</span>
                </div>
              </Card>

              <Card>
                <SLabel>Station Compliance</SLabel>
                <CTitle>{vocFilter}</CTitle>
                <div style={{ height: 200, display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: 8 }}>
                  <Doughnut data={doughnutData} options={{ responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { font: { family: T.fontBody, size: 12 }, color: T.text } } } }} />
                </div>
                <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 8 }}>
                  <div style={{ fontFamily: T.fontBody, fontSize: 13, display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: T.textSub }}>WHO limit</span>
                    <span style={{ fontFamily: T.fontMono, fontWeight: 600, color: T.text }}>{VOC_LIMITS[vocFilter].who} μg/m³</span>
                  </div>
                  <div style={{ fontFamily: T.fontBody, fontSize: 13, display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: T.textSub }}>India NAAQS</span>
                    <span style={{ fontFamily: T.fontMono, fontWeight: 600, color: T.text }}>{VOC_LIMITS[vocFilter].india} μg/m³</span>
                  </div>
                  <div style={{ fontFamily: T.fontBody, fontSize: 13, display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: T.textSub }}>Stations violated</span>
                    <span style={{ fontFamily: T.fontMono, fontWeight: 700, color: T.danger }}>{exceededCount}/{totalVOC}</span>
                  </div>
                  {VOC_LIMITS[vocFilter].carcinogen && (
                    <div style={{ marginTop: 8, padding: '8px 12px', background: T.dangerLight, border: `1px solid ${T.danger}33`, borderRadius: 8, fontFamily: T.fontBody, fontSize: 12, color: T.danger }}>
                      ⚠️ IARC Group 1 Carcinogen — no safe exposure level
                    </div>
                  )}
                </div>
              </Card>
            </div>

            {/* Station table */}
            <Card>
              <SLabel color={T.danger}>Station-Level {VOC_LIMITS[vocFilter].label} Readings</SLabel>
              <CTitle>{showOnlyExceeded ? `${exceededCount} Stations Exceeding WHO Limit` : `All ${totalVOC} Stations with ${vocFilter} Data`}</CTitle>
              <div style={{ overflowX: 'auto', marginTop: 16 }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontFamily: T.fontBody, fontSize: 13 }}>
                  <thead>
                    <tr style={{ borderBottom: `2px solid ${T.border}` }}>
                      {['#', 'Station', 'State', vocFilter, '× WHO Limit', 'Benzene', 'Toluene', 'Eth-Benz', 'Status'].map(h => (
                        <th key={h} style={{ padding: '8px 12px', textAlign: 'left', fontFamily: T.fontMono, fontSize: 10, color: T.textSub, letterSpacing: '0.06em', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {vocRows.slice(0, 60).map((r, i) => (
                      <tr key={i} style={{ borderBottom: `1px solid ${T.border}`, background: r.exceeded ? 'rgba(220,38,38,0.04)' : 'transparent' }}>
                        <td style={{ padding: '9px 12px', fontFamily: T.fontMono, color: T.textSub }}>{i + 1}</td>
                        <td style={{ padding: '9px 12px', fontWeight: 600, maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.station.replace(/ - .+$/, '')}</td>
                        <td style={{ padding: '9px 12px', fontFamily: T.fontMono, fontSize: 11, color: T.textSub }}>{r.state}</td>
                        <td style={{ padding: '9px 12px', fontFamily: T.fontDisplay, fontWeight: 700, color: r.exceeded ? T.danger : T.good }}>{r.value.toFixed(2)}</td>
                        <td style={{ padding: '9px 12px', fontFamily: T.fontMono, fontWeight: 600, color: r.ratio > 5 ? T.danger : r.ratio > 1 ? T.warn : T.good }}>{r.ratio.toFixed(1)}×</td>
                        <td style={{ padding: '9px 12px', fontFamily: T.fontMono, fontSize: 12, color: (r.allVOC['Benzene'] || 0) > 1.7 ? T.danger : T.textSub }}>{r.allVOC['Benzene']?.toFixed(2) ?? '—'}</td>
                        <td style={{ padding: '9px 12px', fontFamily: T.fontMono, fontSize: 12 }}>{r.allVOC['Toluene']?.toFixed(1) ?? '—'}</td>
                        <td style={{ padding: '9px 12px', fontFamily: T.fontMono, fontSize: 12, color: (r.allVOC['Eth-Benzene'] || 0) > 22 ? T.warn : T.textSub }}>{r.allVOC['Eth-Benzene']?.toFixed(2) ?? '—'}</td>
                        <td style={{ padding: '9px 12px' }}>
                          <span style={{ fontFamily: T.fontMono, fontSize: 10, padding: '2px 8px', borderRadius: 99, background: r.exceeded ? T.dangerLight : T.goodLight, color: r.exceeded ? T.danger : T.good, border: `1px solid ${r.exceeded ? T.danger : T.good}44` }}>
                            {r.exceeded ? '⚠ EXCEEDED' : '✓ SAFE'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {vocRows.length > 60 && (
                  <div style={{ textAlign: 'center', padding: '12px 0', fontFamily: T.fontMono, fontSize: 12, color: T.textSub }}>
                    Showing top 60 of {vocRows.length} stations
                  </div>
                )}
              </div>
            </Card>
          </div>
        )}
      </div>

      <style>{`@keyframes slideIn { from { transform: translateX(120%); opacity:0; } to { transform: translateX(0); opacity:1; } }`}</style>
    </div>
  );
}
