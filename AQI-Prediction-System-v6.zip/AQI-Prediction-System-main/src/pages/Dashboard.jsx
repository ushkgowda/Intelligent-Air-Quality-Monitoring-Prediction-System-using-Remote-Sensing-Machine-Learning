import { useState, useEffect, useCallback } from 'react';
import {
  loadStations,
  aggregateByState,
  nationalSummary,
  getStateTrendAndForecast,
  aqiCategory,
} from '../utils/aqiData';
import AQIGauge from '../components/AQIGauge';
import StateRankingChart from '../components/StateRankingChart';
import TrendForecastChart from '../components/TrendForecastChart';
import PollutantRadar from '../components/PollutantRadar';

// ─── Design tokens ──────────────────────────────────────────────────────────
const T = {
  bg: '#f0f4f8',
  surface: '#ffffff',
  surfaceAlt: '#f8fafc',
  border: 'rgba(148,163,184,0.28)',
  text: '#16202c',
  textSub: '#5b6b7c',
  accent: '#1d4ed8',
  accentLight: 'rgba(29,78,216,0.08)',
  fontDisplay: "'Space Grotesk', sans-serif",
  fontBody: "'Inter', sans-serif",
  fontMono: "'IBM Plex Mono', monospace",
  radius: '12px',
  shadow: '0 1px 4px rgba(0,0,0,0.07), 0 4px 16px rgba(0,0,0,0.05)',
};

// ─── Sub-components ──────────────────────────────────────────────────────────

function Card({ children, style = {} }) {
  return (
    <div style={{
      background: T.surface,
      borderRadius: T.radius,
      border: `1px solid ${T.border}`,
      boxShadow: T.shadow,
      padding: '24px',
      ...style,
    }}>
      {children}
    </div>
  );
}

function SectionLabel({ children }) {
  return (
    <div style={{
      fontFamily: T.fontMono,
      fontSize: 11,
      fontWeight: 600,
      letterSpacing: '0.12em',
      color: T.textSub,
      textTransform: 'uppercase',
      marginBottom: 12,
    }}>{children}</div>
  );
}

function CardTitle({ children }) {
  return (
    <h2 style={{
      fontFamily: T.fontDisplay,
      fontWeight: 700,
      fontSize: 18,
      color: T.text,
      margin: '0 0 4px 0',
    }}>{children}</h2>
  );
}

function StatPill({ label, value, color }) {
  return (
    <div style={{
      background: T.surfaceAlt,
      border: `1px solid ${T.border}`,
      borderRadius: 8,
      padding: '10px 16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 2,
      minWidth: 120,
    }}>
      <span style={{ fontFamily: T.fontMono, fontSize: 11, color: T.textSub, letterSpacing: '0.08em', textTransform: 'uppercase' }}>{label}</span>
      <span style={{ fontFamily: T.fontDisplay, fontWeight: 700, fontSize: 22, color: color || T.text }}>{value ?? '--'}</span>
    </div>
  );
}

function AQIBadge({ aqi }) {
  const cat = aqiCategory(aqi);
  return (
    <span style={{
      fontFamily: T.fontMono,
      fontSize: 11,
      fontWeight: 600,
      padding: '2px 8px',
      borderRadius: 99,
      background: cat.color + '22',
      color: cat.color,
      border: `1px solid ${cat.color}55`,
    }}>{cat.label}</span>
  );
}

function StationList({ stations, onSelect, selected }) {
  const [query, setQuery] = useState('');
  const filtered = stations
    .filter((s) => s.station?.toLowerCase().includes(query.toLowerCase()) || s.state?.toLowerCase().includes(query.toLowerCase()))
    .slice(0, 40);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
      <input
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search station or state…"
        style={{
          fontFamily: T.fontBody,
          fontSize: 13,
          border: `1px solid ${T.border}`,
          borderRadius: 8,
          padding: '8px 12px',
          marginBottom: 10,
          outline: 'none',
          color: T.text,
          background: T.surfaceAlt,
        }}
      />
      <div style={{ maxHeight: 340, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 2 }}>
        {filtered.map((s, i) => {
          const cat = aqiCategory(s.aqi);
          const isSelected = selected?.station === s.station;
          return (
            <button
              key={i}
              onClick={() => onSelect(s)}
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '9px 12px',
                borderRadius: 8,
                border: isSelected ? `1.5px solid ${T.accent}` : `1px solid transparent`,
                background: isSelected ? T.accentLight : 'transparent',
                cursor: 'pointer',
                textAlign: 'left',
                transition: 'background 0.15s',
              }}
            >
              <div>
                <div style={{ fontFamily: T.fontBody, fontSize: 13, fontWeight: 600, color: T.text, lineHeight: 1.3 }}>{s.station?.replace(/ - .+$/, '') || '—'}</div>
                <div style={{ fontFamily: T.fontMono, fontSize: 11, color: T.textSub }}>{s.state}</div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 3 }}>
                <span style={{ fontFamily: T.fontDisplay, fontWeight: 700, fontSize: 16, color: cat.color }}>{s.aqi}</span>
                <AQIBadge aqi={s.aqi} />
              </div>
            </button>
          );
        })}
        {filtered.length === 0 && (
          <div style={{ fontFamily: T.fontBody, fontSize: 13, color: T.textSub, padding: '16px 0', textAlign: 'center' }}>No stations match "{query}"</div>
        )}
      </div>
    </div>
  );
}

// ─── Live clock ─────────────────────────────────────────────────────────────
function LiveClock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return (
    <span style={{ fontFamily: T.fontMono, fontSize: 13, color: T.textSub }}>
      {now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
      {' · '}{now.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
    </span>
  );
}

// ─── Main Dashboard ──────────────────────────────────────────────────────────
export default function Dashboard() {
  const [stations, setStations] = useState([]);
  const [byState, setByState] = useState([]);
  const [summary, setSummary] = useState(null);
  const [selectedStation, setSelectedStation] = useState(null);
  const [selectedState, setSelectedState] = useState('Delhi');
  const [trend, setTrend] = useState({ history: [], forecast: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('overview'); // overview | stations | forecast

  useEffect(() => {
    loadStations()
      .then((data) => {
        setStations(data);
        const agg = aggregateByState(data);
        setByState(agg);
        setSummary(nationalSummary(data));
        // Default select most-polluted station
        const mostPolluted = [...data].sort((a, b) => b.pm25 - a.pm25)[0];
        setSelectedStation(mostPolluted);
        setLoading(false);
      })
      .catch((e) => { setError(e.message); setLoading(false); });
  }, []);

  useEffect(() => {
    if (stations.length && selectedState) {
      setTrend(getStateTrendAndForecast(stations, selectedState, 4));
    }
  }, [stations, selectedState]);

  const handleStateClick = useCallback((state) => {
    setSelectedState(state);
    setActiveTab('forecast');
  }, []);

  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '80vh', fontFamily: T.fontBody, color: T.textSub }}>
      Loading station data…
    </div>
  );
  if (error) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '80vh', fontFamily: T.fontBody, color: '#dc2626' }}>
      Error: {error}
    </div>
  );

  const topState = byState[0];
  const cleanState = byState[byState.length - 1];

  return (
    <div style={{ background: T.bg, minHeight: '100vh', padding: '0 0 60px 0', fontFamily: T.fontBody, boxSizing: 'border-box' }}>

      {/* ── Hero band ────────────────────────────────────── */}
      <div style={{
        background: 'linear-gradient(135deg, #16202c 0%, #1d2e45 60%, #1a3558 100%)',
        padding: '36px 40px 32px',
        display: 'flex',
        flexWrap: 'wrap',
        alignItems: 'center',
        gap: 40,
        justifyContent: 'space-between',
      }}>
        {/* Gauge */}
        <div>
          <SectionLabel style={{ color: '#7a9bb5' }}>National Average · India</SectionLabel>
          {summary && <AQIGauge value={summary.avgAqi} label={`${summary.stationCount} monitoring stations`} size={240} />}
        </div>

        {/* KPI pills */}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 16, flex: 1, justifyContent: 'center' }}>
          <StatPill label="Avg PM2.5" value={`${summary?.avgPm25} μg`} color="#f5c518" />
          <StatPill label="Stations" value={summary?.stationCount} color="#3aa757" />
          <StatPill
            label="Most Polluted"
            value={topState?.state}
            color={aqiCategory(topState?.avgAqi).color}
          />
          <StatPill
            label="Cleanest State"
            value={cleanState?.state}
            color="#3aa757"
          />
        </div>

        {/* Live clock + legend */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 16 }}>
          <LiveClock />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
            {[
              ['Good', '#3aa757', '0–50'],
              ['Satisfactory', '#a3c853', '51–100'],
              ['Moderate', '#f5c518', '101–200'],
              ['Poor', '#f97316', '201–300'],
              ['Very Poor', '#dc2626', '301–400'],
              ['Severe', '#7f1d1d', '401–500'],
            ].map(([label, color, range]) => (
              <div key={label} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ width: 10, height: 10, borderRadius: 2, background: color, display: 'inline-block' }} />
                <span style={{ fontFamily: T.fontMono, fontSize: 11, color: '#8fafc9' }}>{label}</span>
                <span style={{ fontFamily: T.fontMono, fontSize: 11, color: '#5b7a96' }}>{range}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Tab nav ─────────────────────────────────────── */}
      <div style={{
        background: T.surface,
        borderBottom: `1px solid ${T.border}`,
        padding: '0 40px',
        display: 'flex',
        gap: 0,
      }}>
        {[
          { id: 'overview', label: 'Overview' },
          { id: 'stations', label: 'Stations' },
          { id: 'forecast', label: `Forecast · ${selectedState}` },
        ].map(({ id, label }) => (
          <button
            key={id}
            onClick={() => setActiveTab(id)}
            style={{
              fontFamily: T.fontDisplay,
              fontWeight: 600,
              fontSize: 14,
              padding: '16px 24px',
              border: 'none',
              borderBottom: activeTab === id ? `2.5px solid ${T.accent}` : '2.5px solid transparent',
              background: 'transparent',
              color: activeTab === id ? T.accent : T.textSub,
              cursor: 'pointer',
              transition: 'color 0.15s',
            }}
          >{label}</button>
        ))}
      </div>

      {/* ── Tab content ─────────────────────────────────── */}
      <div style={{ padding: '32px 40px', maxWidth: 1440, margin: '0 auto' }}>

        {/* OVERVIEW */}
        {activeTab === 'overview' && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
            {/* State ranking */}
            <Card style={{ gridColumn: '1 / -1' }}>
              <SectionLabel>Air Quality Ranking by State</SectionLabel>
              <CardTitle>Top {Math.min(15, byState.length)} States — Worst AQI</CardTitle>
              <p style={{ fontFamily: T.fontBody, fontSize: 13, color: T.textSub, marginTop: 4, marginBottom: 20 }}>
                Click any bar to view that state's PM2.5 trend and forecast.
              </p>
              <StateRankingChart states={byState} topN={15} onStateClick={handleStateClick} />
            </Card>

            {/* Most / least polluted */}
            <Card>
              <SectionLabel>Most Polluted Station</SectionLabel>
              <CardTitle>{stations.sort((a, b) => b.pm25 - a.pm25)[0]?.station?.replace(/ - .+$/, '')}</CardTitle>
              <div style={{ fontFamily: T.fontMono, fontSize: 12, color: T.textSub, margin: '4px 0 16px' }}>
                {stations[0]?.state} · PM2.5 {stations.sort((a, b) => b.pm25 - a.pm25)[0]?.pm25} μg/m³
              </div>
              <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
                <StatPill label="AQI" value={stations.sort((a, b) => b.pm25 - a.pm25)[0]?.aqi} color="#dc2626" />
                <StatPill label="PM10" value={`${Math.round(stations.sort((a, b) => b.pm25 - a.pm25)[0]?.pm10 ?? 0)}`} />
              </div>
            </Card>

            <Card>
              <SectionLabel>Cleanest Station</SectionLabel>
              <CardTitle>{stations.sort((a, b) => a.pm25 - b.pm25)[0]?.station?.replace(/ - .+$/, '')}</CardTitle>
              <div style={{ fontFamily: T.fontMono, fontSize: 12, color: T.textSub, margin: '4px 0 16px' }}>
                {stations.sort((a, b) => a.pm25 - b.pm25)[0]?.state} · PM2.5 {stations.sort((a, b) => a.pm25 - b.pm25)[0]?.pm25} μg/m³
              </div>
              <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
                <StatPill label="AQI" value={stations.sort((a, b) => a.pm25 - b.pm25)[0]?.aqi} color="#3aa757" />
                <StatPill label="PM10" value={`${Math.round(stations.sort((a, b) => a.pm25 - b.pm25)[0]?.pm10 ?? 0)}`} />
              </div>
            </Card>

            {/* State summary table */}
            <Card style={{ gridColumn: '1 / -1' }}>
              <SectionLabel>All States Summary</SectionLabel>
              <CardTitle>AQI by State</CardTitle>
              <div style={{ overflowX: 'auto', marginTop: 16 }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontFamily: T.fontBody, fontSize: 13 }}>
                  <thead>
                    <tr style={{ borderBottom: `2px solid ${T.border}` }}>
                      {['Rank', 'State', 'Avg PM2.5', 'Avg AQI', 'Category', 'Stations'].map((h) => (
                        <th key={h} style={{ padding: '8px 12px', textAlign: 'left', fontFamily: T.fontMono, fontSize: 11, color: T.textSub, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {byState.map((s, i) => (
                      <tr
                        key={s.state}
                        style={{ borderBottom: `1px solid ${T.border}`, cursor: 'pointer', transition: 'background 0.12s' }}
                        onClick={() => { setSelectedState(s.state); setActiveTab('forecast'); }}
                        onMouseEnter={(e) => e.currentTarget.style.background = T.accentLight}
                        onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                      >
                        <td style={{ padding: '10px 12px', fontFamily: T.fontMono, color: T.textSub }}>{i + 1}</td>
                        <td style={{ padding: '10px 12px', fontWeight: 600 }}>{s.state}</td>
                        <td style={{ padding: '10px 12px', fontFamily: T.fontMono }}>{s.avgPm25} μg/m³</td>
                        <td style={{ padding: '10px 12px', fontFamily: T.fontDisplay, fontWeight: 700, color: aqiCategory(s.avgAqi).color }}>{s.avgAqi}</td>
                        <td style={{ padding: '10px 12px' }}><AQIBadge aqi={s.avgAqi} /></td>
                        <td style={{ padding: '10px 12px', fontFamily: T.fontMono }}>{s.stationCount}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        )}

        {/* STATIONS */}
        {activeTab === 'stations' && (
          <div style={{ display: 'grid', gridTemplateColumns: '360px 1fr', gap: 24 }}>
            <Card>
              <SectionLabel>Station Browser</SectionLabel>
              <CardTitle>All Stations</CardTitle>
              <p style={{ fontFamily: T.fontBody, fontSize: 13, color: T.textSub, marginBottom: 12 }}>Select a station to see its pollutant breakdown.</p>
              <StationList stations={[...stations].sort((a, b) => b.aqi - a.aqi)} onSelect={setSelectedStation} selected={selectedStation} />
            </Card>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
              {selectedStation ? (
                <>
                  <Card>
                    <SectionLabel>Station Detail</SectionLabel>
                    <CardTitle>{selectedStation.station?.replace(/ - .+$/, '') || '—'}</CardTitle>
                    <div style={{ fontFamily: T.fontMono, fontSize: 12, color: T.textSub, margin: '4px 0 16px' }}>
                      {selectedStation.state} · {selectedStation.lat?.toFixed(4)}, {selectedStation.lon?.toFixed(4)}
                    </div>
                    <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 20 }}>
                      <StatPill label="AQI" value={selectedStation.aqi} color={aqiCategory(selectedStation.aqi).color} />
                      <StatPill label="PM2.5" value={`${selectedStation.pm25} μg`} color="#f5c518" />
                      <StatPill label="PM10" value={`${Math.round(selectedStation.pm10 ?? 0)} μg`} />
                      <StatPill label="NO₂" value={`${Math.round(selectedStation.no2 ?? 0)}`} />
                      <StatPill label="SO₂" value={`${Math.round(selectedStation.so2 ?? 0)}`} />
                      <StatPill label="CO" value={`${selectedStation.co ?? '--'}`} />
                      <StatPill label="O₃" value={`${Math.round(selectedStation.ozone ?? 0)}`} />
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{ fontFamily: T.fontBody, fontSize: 13, color: T.textSub }}>Category:</span>
                      <AQIBadge aqi={selectedStation.aqi} />
                      <button
                        onClick={() => { setSelectedState(selectedStation.state); setActiveTab('forecast'); }}
                        style={{
                          marginLeft: 'auto',
                          fontFamily: T.fontBody,
                          fontSize: 13,
                          fontWeight: 600,
                          padding: '7px 16px',
                          background: T.accent,
                          color: '#fff',
                          border: 'none',
                          borderRadius: 8,
                          cursor: 'pointer',
                        }}
                      >
                        View {selectedStation.state} Forecast →
                      </button>
                    </div>
                  </Card>

                  <Card>
                    <SectionLabel>Pollutant Breakdown</SectionLabel>
                    <CardTitle>% of CPCB Safe Limit</CardTitle>
                    <p style={{ fontFamily: T.fontBody, fontSize: 13, color: T.textSub, marginBottom: 16 }}>Values above 100% exceed the 24-hour standard.</p>
                    <PollutantRadar station={{
                      'PM2.5': selectedStation.pm25,
                      'PM10': selectedStation.pm10,
                      'NO2': selectedStation.no2,
                      'SO2': selectedStation.so2,
                      'CO': selectedStation.co,
                      'Ozone': selectedStation.ozone,
                    }} />
                  </Card>
                </>
              ) : (
                <Card style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: 300 }}>
                  <span style={{ fontFamily: T.fontBody, color: T.textSub }}>Select a station from the list.</span>
                </Card>
              )}
            </div>
          </div>
        )}

        {/* FORECAST */}
        {activeTab === 'forecast' && (
          <div style={{ display: 'grid', gridTemplateColumns: '240px 1fr', gap: 24 }}>
            {/* State picker */}
            <Card>
              <SectionLabel>Select State</SectionLabel>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 4, maxHeight: 560, overflowY: 'auto' }}>
                {byState.map((s) => (
                  <button
                    key={s.state}
                    onClick={() => setSelectedState(s.state)}
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      padding: '9px 12px',
                      borderRadius: 8,
                      border: selectedState === s.state ? `1.5px solid ${T.accent}` : '1px solid transparent',
                      background: selectedState === s.state ? T.accentLight : 'transparent',
                      cursor: 'pointer',
                      transition: 'background 0.12s',
                    }}
                  >
                    <span style={{ fontFamily: T.fontBody, fontSize: 13, fontWeight: 600, color: T.text }}>{s.state}</span>
                    <span style={{ fontFamily: T.fontDisplay, fontWeight: 700, fontSize: 14, color: aqiCategory(s.avgAqi).color }}>{s.avgAqi}</span>
                  </button>
                ))}
              </div>
            </Card>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
              {/* Gauge for selected state */}
              <Card style={{ display: 'flex', gap: 32, alignItems: 'center', flexWrap: 'wrap' }}>
                <div>
                  <SectionLabel>Selected State</SectionLabel>
                  <AQIGauge
                    value={byState.find((s) => s.state === selectedState)?.avgAqi}
                    label={`${selectedState} — avg AQI`}
                    size={200}
                  />
                </div>
                <div style={{ flex: 1 }}>
                  <CardTitle>{selectedState} Air Quality</CardTitle>
                  <p style={{ fontFamily: T.fontBody, fontSize: 14, color: T.textSub, marginTop: 8, lineHeight: 1.6 }}>
                    Showing historical monthly PM2.5 averages for {selectedState} stations, with a
                    linear-trend forecast for the next 4 months. The dashed orange line is a
                    statistical projection based on the seasonal pattern in this dataset — not a
                    live weather or atmospheric model.
                  </p>
                  <div style={{ display: 'flex', gap: 12, marginTop: 16, flexWrap: 'wrap' }}>
                    <StatPill
                      label="Stations in state"
                      value={byState.find((s) => s.state === selectedState)?.stationCount}
                    />
                    <StatPill
                      label="Avg PM2.5"
                      value={`${byState.find((s) => s.state === selectedState)?.avgPm25} μg`}
                      color="#f5c518"
                    />
                    {trend.trendSlope != null && (
                      <StatPill
                        label="Monthly trend"
                        value={`${trend.trendSlope > 0 ? '+' : ''}${trend.trendSlope.toFixed(1)} μg`}
                        color={trend.trendSlope > 0 ? '#dc2626' : '#3aa757'}
                      />
                    )}
                  </div>
                </div>
              </Card>

              <Card>
                <SectionLabel>PM2.5 History + Forecast</SectionLabel>
                <CardTitle>{selectedState} — Monthly Average PM2.5</CardTitle>
                <p style={{ fontFamily: T.fontBody, fontSize: 13, color: T.textSub, marginTop: 4, marginBottom: 20 }}>
                  Blue = observed data · Orange dashed = 4-month linear projection
                </p>
                <TrendForecastChart history={trend.history} forecast={trend.forecast} label={selectedState} />
              </Card>

              {/* Forecast table */}
              {trend.forecast.length > 0 && (
                <Card>
                  <SectionLabel>Projected Values</SectionLabel>
                  <CardTitle>4-Month Forecast</CardTitle>
                  <div style={{ overflowX: 'auto', marginTop: 16 }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', fontFamily: T.fontBody, fontSize: 14 }}>
                      <thead>
                        <tr style={{ borderBottom: `2px solid ${T.border}` }}>
                          {['Month', 'Projected PM2.5', 'Projected AQI', 'Expected Category'].map((h) => (
                            <th key={h} style={{ padding: '8px 16px', textAlign: 'left', fontFamily: T.fontMono, fontSize: 11, color: T.textSub, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {trend.forecast.map((f, i) => {
                          const projectedAqi = Math.round((f.pm25 / 60) * 200);
                          const cat = aqiCategory(projectedAqi);
                          return (
                            <tr key={i} style={{ borderBottom: `1px solid ${T.border}` }}>
                              <td style={{ padding: '12px 16px', fontFamily: T.fontDisplay, fontWeight: 600 }}>{f.label}</td>
                              <td style={{ padding: '12px 16px', fontFamily: T.fontMono }}>{f.pm25} μg/m³</td>
                              <td style={{ padding: '12px 16px', fontFamily: T.fontDisplay, fontWeight: 700, color: cat.color }}>{projectedAqi}</td>
                              <td style={{ padding: '12px 16px' }}><AQIBadge aqi={projectedAqi} /></td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </Card>
              )}
            </div>
          </div>
        )}
      </div>

      {/* ── Footer ─────────────────────────────────────────── */}
      <div style={{
        borderTop: `1px solid ${T.border}`,
        padding: '20px 40px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        background: T.surface,
        fontFamily: T.fontMono,
        fontSize: 12,
        color: T.textSub,
      }}>
        <span>Data source: CPCB + INSAT-3DR + MERRA-NASA · {stations.length} station records</span>
        <span>© {new Date().getFullYear()} AQ-INDIA · CPCB AQI Standard</span>
      </div>
    </div>
  );
}
